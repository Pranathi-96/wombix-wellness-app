"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Heart, Clock, ArrowRight } from "lucide-react"

interface Exercise {
  id: string
  name: string
  description: string
  duration: string
  intensity: "Low" | "Medium" | "High"
  benefits: string[]
  tags: string[]
  videoUrl?: string
}

const exerciseCategories = [
  {
    id: "hormonal-balance",
    name: "Hormonal Balance",
    description: "Exercises that help regulate hormones and improve overall hormonal health",
    exercises: [
      {
        id: "yoga-flow",
        name: "Gentle Yoga Flow",
        description:
          "A gentle sequence of yoga poses designed to reduce stress and balance hormones. Focus on deep breathing and mindful movement.",
        duration: "20 min",
        intensity: "Low" as const,
        benefits: [
          "Reduces cortisol levels",
          "Improves blood circulation",
          "Balances endocrine system",
          "Reduces stress and anxiety",
        ],
        tags: ["Yoga", "Stress Reduction", "Hormonal Balance", "PCOS"],
        videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
      },
      {
        id: "pilates-core",
        name: "Pilates Core Workout",
        description:
          "Core-strengthening exercises that improve posture, reduce back pain, and support hormonal balance through improved circulation.",
        duration: "15 min",
        intensity: "Medium" as const,
        benefits: [
          "Strengthens core muscles",
          "Improves posture",
          "Enhances blood flow to reproductive organs",
          "Reduces back pain",
        ],
        tags: ["Pilates", "Core Strength", "Posture", "Endometriosis"],
      },
      {
        id: "tai-chi",
        name: "Tai Chi for Balance",
        description:
          "Slow, flowing movements that reduce stress, improve balance, and promote hormonal harmony through mindful movement.",
        duration: "25 min",
        intensity: "Low" as const,
        benefits: [
          "Reduces stress hormones",
          "Improves mind-body connection",
          "Enhances balance and coordination",
          "Gentle on joints",
        ],
        tags: ["Tai Chi", "Balance", "Mindfulness", "Menopause"],
      },
    ],
  },
  {
    id: "pcos-specific",
    name: "PCOS Support",
    description: "Exercises specifically designed to help manage PCOS symptoms",
    exercises: [
      {
        id: "hiit-pcos",
        name: "PCOS-Friendly HIIT",
        description:
          "A modified high-intensity interval training workout designed specifically for women with PCOS to improve insulin sensitivity.",
        duration: "20 min",
        intensity: "High" as const,
        benefits: [
          "Improves insulin sensitivity",
          "Reduces testosterone levels",
          "Promotes weight management",
          "Boosts metabolism",
        ],
        tags: ["HIIT", "Insulin Resistance", "PCOS", "Weight Management"],
        videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
      },
      {
        id: "strength-pcos",
        name: "Strength Training for PCOS",
        description:
          "Resistance training exercises that help build lean muscle mass, which improves metabolic health and hormone balance.",
        duration: "30 min",
        intensity: "Medium" as const,
        benefits: [
          "Builds lean muscle mass",
          "Improves metabolic rate",
          "Enhances insulin sensitivity",
          "Reduces inflammation",
        ],
        tags: ["Strength Training", "Muscle Building", "PCOS", "Metabolism"],
      },
      {
        id: "yoga-pcos",
        name: "Yoga for PCOS",
        description:
          "Specific yoga poses that target hormonal balance, reduce stress, and improve blood flow to reproductive organs.",
        duration: "25 min",
        intensity: "Low" as const,
        benefits: [
          "Reduces androgen levels",
          "Decreases stress hormones",
          "Improves ovarian function",
          "Enhances fertility",
        ],
        tags: ["Yoga", "PCOS", "Hormonal Balance", "Stress Reduction"],
        videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
      },
    ],
  },
  {
    id: "pain-management",
    name: "Pain Relief",
    description: "Exercises to help manage menstrual pain, endometriosis, and other pain conditions",
    exercises: [
      {
        id: "pelvic-stretches",
        name: "Pelvic Stretching Routine",
        description:
          "Gentle stretches targeting the pelvic region to relieve tension, improve flexibility, and reduce menstrual pain.",
        duration: "15 min",
        intensity: "Low" as const,
        benefits: [
          "Relieves pelvic tension",
          "Reduces menstrual cramps",
          "Improves pelvic circulation",
          "Increases flexibility",
        ],
        tags: ["Stretching", "Pelvic Pain", "Menstrual Cramps", "Endometriosis"],
      },
      {
        id: "swimming",
        name: "Gentle Swimming",
        description:
          "Low-impact swimming exercises that provide pain relief through gentle movement and the natural compression of water.",
        duration: "30 min",
        intensity: "Medium" as const,
        benefits: [
          "Reduces joint pressure",
          "Improves circulation",
          "Provides gentle resistance",
          "Releases endorphins",
        ],
        tags: ["Swimming", "Low Impact", "Pain Relief", "Endometriosis"],
      },
      {
        id: "walking-meditation",
        name: "Walking Meditation",
        description:
          "A mindful walking practice that combines gentle movement with meditation to reduce pain perception and stress.",
        duration: "20 min",
        intensity: "Low" as const,
        benefits: [
          "Reduces stress hormones",
          "Improves mood",
          "Gentle cardiovascular exercise",
          "Enhances mind-body connection",
        ],
        tags: ["Walking", "Meditation", "Stress Reduction", "Chronic Pain"],
      },
    ],
  },
  {
    id: "energy-boost",
    name: "Energy & Mood",
    description: "Exercises to boost energy levels, improve mood, and combat fatigue",
    exercises: [
      {
        id: "morning-cardio",
        name: "Morning Cardio Boost",
        description:
          "A quick morning cardio routine designed to increase energy levels, improve mood, and set a positive tone for the day.",
        duration: "15 min",
        intensity: "Medium" as const,
        benefits: ["Increases energy levels", "Boosts endorphins", "Improves circulation", "Enhances mental clarity"],
        tags: ["Cardio", "Energy", "Morning Routine", "Mood Enhancement"],
      },
      {
        id: "dance-workout",
        name: "Dance Fitness",
        description: "A fun dance workout that boosts mood through rhythmic movement, music, and self-expression.",
        duration: "25 min",
        intensity: "Medium" as const,
        benefits: [
          "Releases endorphins",
          "Improves coordination",
          "Boosts cardiovascular health",
          "Reduces stress and anxiety",
        ],
        tags: ["Dance", "Mood", "Energy", "Stress Relief"],
      },
      {
        id: "outdoor-walking",
        name: "Nature Walk",
        description:
          "A mindful outdoor walking routine that combines the mood-boosting benefits of nature with gentle exercise.",
        duration: "30 min",
        intensity: "Low" as const,
        benefits: [
          "Increases vitamin D levels",
          "Improves mood through nature exposure",
          "Gentle cardiovascular exercise",
          "Reduces mental fatigue",
        ],
        tags: ["Walking", "Nature", "Mood", "Energy"],
      },
    ],
  },
]

export function ExerciseRecommendations() {
  const [userData, setUserData] = useState<any>(null)
  const [selectedExercise, setSelectedExercise] = useState<Exercise | null>(null)
  const [showExerciseDetail, setShowExerciseDetail] = useState(false)

  useEffect(() => {
    // Get user data from localStorage
    const userDataStr = localStorage.getItem("wombix_user")
    if (userDataStr) {
      try {
        setUserData(JSON.parse(userDataStr))
      } catch (error) {
        console.error("Error parsing user data:", error)
      }
    }
  }, [])

  const handleExerciseClick = (exercise: Exercise) => {
    setSelectedExercise(exercise)
    setShowExerciseDetail(true)
  }

  const handleBackClick = () => {
    setShowExerciseDetail(false)
  }

  const getRecommendedCategories = () => {
    if (!userData || !userData.conditions) return exerciseCategories

    // Filter categories based on user conditions
    const userConditions = userData.conditions.map((c: string) => c.toLowerCase())

    // Always include these categories
    const essentialCategories = ["hormonal-balance", "energy-boost"]

    // Add condition-specific categories
    if (userConditions.some((c: string) => c.includes("pcos"))) {
      essentialCategories.push("pcos-specific")
    }

    if (userConditions.some((c: string) => c.includes("endometriosis") || c.includes("cramps") || c.includes("pain"))) {
      essentialCategories.push("pain-management")
    }

    return exerciseCategories.filter((cat) => essentialCategories.includes(cat.id))
  }

  const recommendedCategories = getRecommendedCategories()

  return (
    <Card className="w-full border-pink-200 shadow-sm">
      <CardHeader className="bg-gradient-to-r from-pink-500/5 to-purple-500/5">
        <CardTitle>Exercise Recommendations</CardTitle>
        <CardDescription>Personalized exercise suggestions based on your health profile and goals</CardDescription>
      </CardHeader>
      <CardContent className="p-0">
        {!showExerciseDetail ? (
          <Tabs defaultValue={recommendedCategories[0]?.id} className="w-full">
            <TabsList className="w-full rounded-none border-b bg-transparent p-0">
              {recommendedCategories.map((category) => (
                <TabsTrigger
                  key={category.id}
                  value={category.id}
                  className="flex-1 rounded-none border-b-2 border-transparent px-4 py-3 data-[state=active]:border-pink-600 data-[state=active]:bg-transparent data-[state=active]:shadow-none"
                >
                  {category.name}
                </TabsTrigger>
              ))}
            </TabsList>

            {recommendedCategories.map((category) => (
              <TabsContent key={category.id} value={category.id} className="p-4">
                <div className="mb-4">
                  <p className="text-sm text-gray-500">{category.description}</p>
                </div>

                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {category.exercises.map((exercise) => (
                    <Card
                      key={exercise.id}
                      className="overflow-hidden border-gray-200 hover:border-pink-200 hover:shadow-md transition-all cursor-pointer"
                      onClick={() => handleExerciseClick(exercise)}
                    >
                      <div className="bg-gradient-to-r from-pink-500/5 to-purple-500/5 p-4 border-b">
                        <div className="flex justify-between items-start mb-2">
                          <h3 className="font-medium">{exercise.name}</h3>
                          <Badge
                            className={`${
                              exercise.intensity === "Low"
                                ? "bg-green-100 text-green-800"
                                : exercise.intensity === "Medium"
                                  ? "bg-yellow-100 text-yellow-800"
                                  : "bg-red-100 text-red-800"
                            }`}
                          >
                            {exercise.intensity}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-gray-500">
                          <Clock className="h-3.5 w-3.5" />
                          <span>{exercise.duration}</span>
                        </div>
                      </div>
                      <CardContent className="p-4">
                        <p className="text-sm text-gray-600 line-clamp-2 mb-3">{exercise.description}</p>
                        <div className="flex flex-wrap gap-1">
                          {exercise.tags.slice(0, 3).map((tag) => (
                            <Badge key={tag} variant="outline" className="bg-gray-50">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        ) : (
          selectedExercise && (
            <div className="p-4">
              <Button
                variant="ghost"
                size="sm"
                className="mb-4 text-gray-500 hover:text-pink-600"
                onClick={handleBackClick}
              >
                ← Back to exercises
              </Button>

              <div className="mb-6">
                <div className="flex justify-between items-start mb-2">
                  <h2 className="text-xl font-bold">{selectedExercise.name}</h2>
                  <Badge
                    className={`${
                      selectedExercise.intensity === "Low"
                        ? "bg-green-100 text-green-800"
                        : selectedExercise.intensity === "Medium"
                          ? "bg-yellow-100 text-yellow-800"
                          : "bg-red-100 text-red-800"
                    }`}
                  >
                    {selectedExercise.intensity} Intensity
                  </Badge>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
                  <Clock className="h-4 w-4" />
                  <span>{selectedExercise.duration}</span>
                </div>
                <p className="text-gray-700">{selectedExercise.description}</p>
              </div>

              {selectedExercise.videoUrl && (
                <div className="mb-6">
                  <h3 className="text-lg font-medium mb-3">Exercise Video</h3>
                  <div className="aspect-video w-full bg-gray-100 rounded-lg overflow-hidden">
                    <video
                      src={selectedExercise.videoUrl}
                      controls
                      className="w-full h-full object-cover"
                      poster="/placeholder.svg?height=400&width=600"
                    />
                  </div>
                </div>
              )}

              <div className="mb-6">
                <h3 className="text-lg font-medium mb-3">Benefits</h3>
                <ul className="grid gap-2 sm:grid-cols-2">
                  {selectedExercise.benefits.map((benefit, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <div className="rounded-full bg-green-100 p-1 mt-0.5">
                        <Heart className="h-3 w-3 text-green-600" />
                      </div>
                      <span className="text-gray-700">{benefit}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h3 className="text-lg font-medium mb-3">Tags</h3>
                <div className="flex flex-wrap gap-2">
                  {selectedExercise.tags.map((tag) => (
                    <Badge key={tag} className="bg-gray-100 text-gray-800 hover:bg-gray-200">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>

              <div className="mt-6 pt-6 border-t">
                <Button className="w-full bg-pink-600 hover:bg-pink-700">
                  Add to My Exercise Plan <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </div>
          )
        )}
      </CardContent>
    </Card>
  )
}
