"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { resources } from "@/data/resources"

interface RecommendedResourcesProps {
  showAll?: boolean
}

export function RecommendedResources({ showAll = false }: RecommendedResourcesProps) {
  const [userData, setUserData] = useState<any>(null)

  useEffect(() => {
    // Get user data from localStorage
    const userDataStr = localStorage.getItem("wombix_user")
    if (userDataStr) {
      setUserData(JSON.parse(userDataStr))
    }
  }, [])

  if (!userData) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Recommended Resources</CardTitle>
          <CardDescription>Loading your personalized resources...</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-6">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-pink-600"></div>
          </div>
        </CardContent>
      </Card>
    )
  }

  // Filter resources based on user conditions and goals
  const userConditions = userData.conditions || []
  const userGoals = userData.goals || []

  const filteredResources = resources.filter((resource) => {
    // Check if resource tags match any user conditions or goals
    return resource.tags.some(
      (tag) =>
        userConditions.some(
          (condition: string) =>
            condition.toLowerCase().includes(tag.toLowerCase()) || tag.toLowerCase().includes(condition.toLowerCase()),
        ) ||
        userGoals.some(
          (goal: string) =>
            goal.toLowerCase().includes(tag.toLowerCase()) || tag.toLowerCase().includes(goal.toLowerCase()),
        ),
    )
  })

  // Limit to 6 resources unless showAll is true
  const displayResources = showAll ? filteredResources : filteredResources.slice(0, 6)

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recommended Resources</CardTitle>
        <CardDescription>Personalized content based on your health profile</CardDescription>
      </CardHeader>
      <CardContent>
        {displayResources.length === 0 ? (
          <div className="text-center py-6">
            <p className="text-gray-500 mb-4">No personalized resources available yet</p>
            <Link href="/resources">
              <Button>Browse All Resources</Button>
            </Link>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {displayResources.map((resource) => (
                <Link href={`/resources/${resource.id}`} key={resource.id}>
                  <Card className="h-full overflow-hidden hover:shadow-md transition-shadow">
                    <div className="aspect-video relative">
                      <Image
                        src={resource.thumbnail || "/placeholder.svg"}
                        alt={resource.title}
                        fill
                        className="object-cover"
                      />
                      {resource.type === "video" && (
                        <div className="absolute inset-0 flex items-center justify-center">
                          <div className="rounded-full bg-black/50 p-3">
                            <Image src="/play-icon.png" alt="Play" width={24} height={24} />
                          </div>
                        </div>
                      )}
                    </div>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-1">
                        <span
                          className={`text-xs px-2 py-1 rounded-full ${
                            resource.type === "article" ? "bg-blue-100 text-blue-800" : "bg-pink-100 text-pink-800"
                          }`}
                        >
                          {resource.type === "article" ? "Article" : "Video"}
                        </span>
                        <span className="text-xs text-gray-500">{resource.readTime || resource.duration}</span>
                      </div>
                      <h3 className="font-medium line-clamp-2">{resource.title}</h3>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>

            {!showAll && filteredResources.length > 6 && (
              <div className="flex justify-center">
                <Link href="/resources">
                  <Button variant="outline">View All Resources</Button>
                </Link>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
