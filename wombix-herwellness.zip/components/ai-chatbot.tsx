"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Bot, User, X, Send, Minimize, Maximize2 } from "lucide-react"
import { cn } from "@/lib/utils"

interface Message {
  role: "user" | "assistant"
  content: string
  timestamp: Date
}

export function AIChatbot() {
  const [isOpen, setIsOpen] = useState(false)
  const [isMinimized, setIsMinimized] = useState(false)
  const [input, setInput] = useState("")
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "Hi there! I'm your Wombix AI assistant. How can I help you with your health questions today?",
      timestamp: new Date(),
    },
  ])
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  // Predefined responses for common women's health questions
  const predefinedResponses: Record<string, string> = {
    period:
      "Periods typically last 3-7 days and occur every 21-35 days. If you're experiencing irregular periods, it could be due to stress, weight changes, hormonal imbalances, or certain medical conditions. Would you like more specific information?",
    pcos: "Polycystic Ovary Syndrome (PCOS) is a hormonal disorder common among women of reproductive age. Symptoms include irregular periods, excess androgen levels, and polycystic ovaries. Treatment often involves lifestyle changes, medication, and sometimes fertility treatments.",
    endometriosis:
      "Endometriosis is a condition where tissue similar to the lining of the uterus grows outside the uterus. It can cause painful periods, pain during intercourse, and fertility issues. Treatment options include pain medication, hormone therapy, and surgery.",
    pregnancy:
      "Early signs of pregnancy include missed periods, nausea, breast tenderness, and fatigue. If you think you might be pregnant, a home pregnancy test can be accurate from the first day of your missed period. For confirmation, please consult with a healthcare provider.",
    menopause:
      "Menopause is the natural end of menstruation and fertility, typically occurring between ages 45-55. Symptoms can include hot flashes, night sweats, mood changes, and sleep disturbances. There are many management strategies available, from lifestyle changes to hormone therapy.",
    cramps:
      "Menstrual cramps are caused by uterine contractions. To manage them, try heat therapy, gentle exercise, over-the-counter pain relievers, and staying hydrated. If your cramps are severe or disruptive to daily life, please consult a healthcare provider.",
    fertility:
      "Fertility can be affected by age, lifestyle factors, and certain health conditions. If you're trying to conceive, tracking your ovulation, maintaining a healthy lifestyle, and having regular intercourse during your fertile window can help. If you've been trying for over a year without success (or 6 months if over 35), consider consulting a fertility specialist.",
    discharge:
      "Vaginal discharge varies throughout your cycle and is usually normal. Clear or white discharge with minimal odor is typically healthy. Changes in color, consistency, odor, or accompanying symptoms like itching or burning may indicate an infection and should be evaluated by a healthcare provider.",
    exercise:
      "Regular exercise is beneficial for women's health in many ways. For PCOS, a combination of cardio and strength training can help improve insulin sensitivity. For endometriosis, low-impact exercises like swimming, walking, and yoga may help manage pain. Would you like specific exercise recommendations for your condition?",
    yoga: "Yoga can be particularly beneficial for women's health issues. For PCOS, poses like Butterfly, Bridge, and Fish pose may help balance hormones. For menstrual pain, Child's pose, Cat-Cow, and Reclined Bound Angle pose can provide relief. Would you like a specific yoga routine recommendation?",
    diet: "Diet plays a crucial role in managing women's health conditions. For PCOS, focus on anti-inflammatory foods, low glycemic index options, and plenty of fiber. For endometriosis, an anti-inflammatory diet rich in omega-3s and low in processed foods may help reduce symptoms. Would you like more specific dietary recommendations?",
    weight:
      "Weight management can be challenging with hormonal conditions like PCOS. Focus on sustainable habits rather than restrictive dieting. A combination of regular exercise, balanced nutrition, stress management, and adequate sleep is most effective. Would you like specific strategies for your situation?",
    nutrition:
      "Nutrition is foundational for hormonal health. Focus on whole foods, healthy fats (avocados, olive oil, nuts), lean proteins, and complex carbohydrates. Limit processed foods, refined sugars, and inflammatory oils. Would you like a personalized nutrition plan based on your specific health concerns?",
    "anti-inflammatory":
      "An anti-inflammatory diet can help manage many women's health conditions. Key foods include fatty fish (salmon, mackerel), colorful fruits and vegetables, nuts, seeds, olive oil, and spices like turmeric and ginger. Would you like specific anti-inflammatory recipes?",
    "seed cycling":
      "Seed cycling is a natural method to support hormone balance throughout your menstrual cycle. During the follicular phase (days 1-14), consume 1-2 tablespoons each of flax and pumpkin seeds daily. During the luteal phase (days 15-28), switch to sesame and sunflower seeds. This practice may help regulate periods and reduce PMS symptoms.",
    "hormone balance":
      "To support hormone balance naturally, focus on: 1) Eating plenty of fiber and cruciferous vegetables to help eliminate excess estrogen, 2) Consuming healthy fats for hormone production, 3) Managing stress through mindfulness practices, 4) Getting adequate sleep, 5) Reducing exposure to endocrine disruptors in plastics and conventional beauty products.",
    "blood sugar":
      "Balancing blood sugar is crucial for hormonal health, especially with PCOS. Include protein and healthy fat with each meal, choose complex carbohydrates over simple ones, eat regularly throughout the day, and consider adding cinnamon, chromium-rich foods, and apple cider vinegar to your diet.",
    "gut health":
      "Gut health directly impacts hormonal balance. To support your gut microbiome, include fermented foods (yogurt, kefir, sauerkraut), prebiotic-rich foods (garlic, onions, bananas), plenty of fiber, and consider a high-quality probiotic supplement. Limit processed foods, artificial sweeteners, and excessive alcohol.",
    "meal plan":
      "A hormone-balancing meal plan should include: Breakfast with protein and healthy fats (like eggs with avocado), lunch with lean protein and plenty of vegetables, afternoon snack with protein and fiber (like apple with almond butter), and dinner with quality protein, complex carbs, and healthy fats. Would you like a specific 7-day meal plan?",
    "pcos diet":
      "For PCOS, focus on a low-glycemic diet that helps manage insulin resistance. Include lean proteins, healthy fats, and high-fiber foods with each meal. Limit refined carbohydrates and sugars. Anti-inflammatory foods like berries, leafy greens, fatty fish, and turmeric are particularly beneficial. Would you like a PCOS-specific meal plan?",
    "endometriosis diet":
      "For endometriosis, an anti-inflammatory diet may help manage symptoms. Focus on omega-3 rich foods (fatty fish, walnuts, flaxseeds), colorful fruits and vegetables, and fiber-rich foods. Consider limiting gluten, dairy, red meat, and alcohol, which may increase inflammation for some women. Would you like specific anti-inflammatory recipes?",
    "thyroid diet":
      "For thyroid health, ensure adequate iodine intake through seafood or iodized salt, selenium from Brazil nuts and eggs, zinc from meat and legumes, and iron from leafy greens and meat. Some women with thyroid conditions may benefit from limiting goitrogenic foods like raw cruciferous vegetables. Always consult your healthcare provider for personalized advice.",
    "fertility diet":
      "To support fertility, focus on a Mediterranean-style diet rich in vegetables, fruits, whole grains, lean proteins, and healthy fats. Include folate-rich foods (leafy greens, legumes), antioxidant-rich foods (berries, colorful vegetables), and omega-3 fatty acids (fatty fish, walnuts). Limit caffeine, alcohol, and highly processed foods.",
    "menopause diet":
      "During menopause, focus on calcium and vitamin D-rich foods for bone health, phytoestrogen-containing foods like soy and flaxseeds, plenty of fruits and vegetables, and adequate protein. Limit spicy foods, caffeine, and alcohol which may trigger hot flashes in some women. Stay well-hydrated and maintain a healthy weight.",
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  const handleSend = () => {
    if (!input.trim()) return

    // Add user message
    const userMessage: Message = {
      role: "user",
      content: input,
      timestamp: new Date(),
    }
    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsTyping(true)

    // Simulate AI thinking
    setTimeout(
      () => {
        const response = generateResponse(input.toLowerCase())
        const aiMessage: Message = {
          role: "assistant",
          content: response,
          timestamp: new Date(),
        }
        setMessages((prev) => [...prev, aiMessage])
        setIsTyping(false)
      },
      1000 + Math.random() * 1000,
    ) // Random delay between 1-2 seconds
  }

  const generateResponse = (query: string): string => {
    // Check for exercise-related queries
    if (query.includes("exercise") && query.includes("pcos")) {
      return `For PCOS, these exercises can be particularly beneficial:

1. HIIT (High-Intensity Interval Training): Short bursts of intense activity followed by rest periods. Start with 10-20 minutes, 2-3 times per week.

2. Strength Training: Focus on compound movements like squats, lunges, and rows to build muscle mass, which improves metabolic health.

3. Yoga: Poses like Butterfly, Bridge, and Fish pose may help balance hormones and reduce stress.

4. Walking: Aim for 30 minutes daily at a moderate pace.

Remember to start gradually and be consistent rather than intense. Would you like more details on any of these exercise types?`
    }

    // Check for nutrition-related queries
    if (query.includes("nutrition") && query.includes("pcos")) {
      return `For PCOS, nutrition plays a crucial role in managing symptoms. Here's a comprehensive approach:

1. Focus on low glycemic index foods to manage insulin resistance:
   - Complex carbs like quinoa, brown rice, and sweet potatoes
   - High-fiber vegetables and fruits
   - Legumes like lentils and chickpeas

2. Include anti-inflammatory foods:
   - Fatty fish rich in omega-3s (salmon, sardines)
   - Colorful vegetables and berries
   - Turmeric, ginger, and cinnamon
   - Extra virgin olive oil

3. Prioritize protein with each meal:
   - Lean meats, fish, and eggs
   - Plant proteins like tempeh and legumes
   - Greek yogurt and cottage cheese (if dairy is tolerated)

4. Consider intermittent fasting (with medical supervision)

5. Foods to limit:
   - Refined carbohydrates and sugars
   - Processed foods and trans fats
   - Excessive dairy and gluten (for some women)

Would you like a sample meal plan specifically for PCOS?`
    }

    // Check for keywords in predefined responses
    for (const [keyword, response] of Object.entries(predefinedResponses)) {
      if (query.includes(keyword)) {
        return response
      }
    }

    // Default responses if no keyword match
    const defaultResponses = [
      "That's an interesting question about women's health. While I don't have specific information on that, I recommend discussing it with your healthcare provider for personalized advice.",
      "I understand you're asking about an important health topic. For the most accurate information, it's best to consult with a healthcare professional who can provide guidance based on your specific situation.",
      "Thank you for your question. Women's health is complex and individual. I'd recommend tracking your symptoms in the app and discussing them with your doctor for the most helpful insights.",
      "I appreciate you sharing that concern. The Wombix app can help you track related symptoms, which might provide useful patterns to discuss with your healthcare provider.",
    ]

    return defaultResponses[Math.floor(Math.random() * defaultResponses.length)]
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  const toggleChat = () => {
    setIsOpen(!isOpen)
    setIsMinimized(false)
  }

  const toggleMinimize = () => {
    setIsMinimized(!isMinimized)
  }

  const suggestedQuestions = [
    "What exercises are good for PCOS?",
    "How can I manage menstrual cramps?",
    "What diet helps with hormonal balance?",
    "Tell me about anti-inflammatory foods",
    "What is seed cycling?",
    "How can I improve my gut health?",
  ]

  return (
    <>
      {/* Chat button */}
      <Button
        onClick={toggleChat}
        className={cn(
          "fixed bottom-4 right-4 rounded-full p-3 shadow-lg transition-all duration-300 z-50",
          isOpen ? "bg-red-500 hover:bg-red-600" : "bg-pink-600 hover:bg-pink-700",
        )}
        size="icon"
      >
        {isOpen ? <X className="h-6 w-6" /> : <Bot className="h-6 w-6" />}
      </Button>

      {/* Chat window */}
      <div
        className={cn(
          "fixed bottom-20 right-4 w-80 md:w-96 rounded-lg shadow-xl transition-all duration-300 transform z-40",
          isOpen ? "scale-100 opacity-100" : "scale-95 opacity-0 pointer-events-none",
          isMinimized ? "h-14" : "h-[500px] max-h-[80vh]",
        )}
      >
        <Card className="h-full flex flex-col overflow-hidden border-pink-200">
          <CardHeader className="py-3 px-4 flex flex-row items-center justify-between space-y-0 bg-gradient-to-r from-pink-500 to-purple-600">
            <CardTitle className="text-white flex items-center gap-2 text-base font-medium">
              <Bot className="h-5 w-5" />
              Wombix Health Assistant
            </CardTitle>
            <div className="flex gap-1">
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7 rounded-full text-white hover:bg-white/20"
                onClick={toggleMinimize}
              >
                {isMinimized ? <Maximize2 className="h-4 w-4" /> : <Minimize className="h-4 w-4" />}
              </Button>
            </div>
          </CardHeader>

          {!isMinimized && (
            <>
              <CardContent className="flex-1 overflow-auto p-4 bg-gray-50">
                <div className="space-y-4">
                  {messages.map((message, index) => (
                    <div
                      key={index}
                      className={cn(
                        "flex items-start gap-2 max-w-[85%]",
                        message.role === "user" ? "ml-auto" : "mr-auto",
                      )}
                    >
                      <div
                        className={cn(
                          "rounded-lg p-3",
                          message.role === "user"
                            ? "bg-pink-600 text-white rounded-tr-none"
                            : "bg-white border border-gray-200 rounded-tl-none",
                        )}
                      >
                        <div className="flex items-center gap-2 mb-1">
                          {message.role === "assistant" ? (
                            <Bot className="h-4 w-4 text-pink-600" />
                          ) : (
                            <User className="h-4 w-4 text-white" />
                          )}
                          <span className={cn("text-xs", message.role === "user" ? "text-pink-100" : "text-gray-500")}>
                            {message.role === "assistant" ? "Wombix AI" : "You"}
                          </span>
                        </div>
                        <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                        <div
                          className={cn(
                            "text-xs mt-1 text-right",
                            message.role === "user" ? "text-pink-100" : "text-gray-400",
                          )}
                        >
                          {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                        </div>
                      </div>
                    </div>
                  ))}
                  {isTyping && (
                    <div className="flex items-start gap-2 max-w-[85%] mr-auto">
                      <div className="rounded-lg p-3 bg-white border border-gray-200 rounded-tl-none">
                        <div className="flex items-center gap-2 mb-1">
                          <Bot className="h-4 w-4 text-pink-600" />
                          <span className="text-xs text-gray-500">Wombix AI</span>
                        </div>
                        <div className="flex gap-1">
                          <div
                            className="w-2 h-2 rounded-full bg-pink-600 animate-bounce"
                            style={{ animationDelay: "0ms" }}
                          ></div>
                          <div
                            className="w-2 h-2 rounded-full bg-pink-600 animate-bounce"
                            style={{ animationDelay: "150ms" }}
                          ></div>
                          <div
                            className="w-2 h-2 rounded-full bg-pink-600 animate-bounce"
                            style={{ animationDelay: "300ms" }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </div>
              </CardContent>

              {messages.length === 1 && (
                <div className="px-4 pb-3">
                  <p className="text-xs text-gray-500 mb-2">Try asking about:</p>
                  <div className="flex flex-wrap gap-2">
                    {suggestedQuestions.map((question, index) => (
                      <Button
                        key={index}
                        variant="outline"
                        size="sm"
                        className="text-xs py-1 h-auto"
                        onClick={() => {
                          setInput(question)
                          setTimeout(() => handleSend(), 100)
                        }}
                      >
                        {question}
                      </Button>
                    ))}
                  </div>
                </div>
              )}

              <CardFooter className="p-3 border-t bg-white">
                <div className="flex w-full items-center gap-2">
                  <Input
                    placeholder="Type your health question..."
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={handleKeyDown}
                    className="flex-1 border-gray-300 focus-visible:ring-pink-500"
                  />
                  <Button
                    onClick={handleSend}
                    size="icon"
                    className="bg-pink-600 hover:bg-pink-700"
                    disabled={!input.trim()}
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </CardFooter>
            </>
          )}
        </Card>
      </div>
    </>
  )
}
