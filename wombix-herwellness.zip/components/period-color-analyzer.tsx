"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { InfoIcon, AlertTriangleIcon } from "lucide-react"

const periodColors = [
  {
    id: "bright-red",
    name: "Bright Red",
    color: "#e11d48",
    description: "Fresh blood at the beginning of your period",
    analysis:
      "Bright red blood indicates a healthy, normal flow at the beginning of your period. This is fresh blood being expelled relatively quickly from the uterus.",
    recommendation: "This is typically normal and healthy. Continue tracking your cycle for any changes.",
    concern: false,
  },
  {
    id: "cranberry",
    name: "Cranberry",
    color: "#9f1239",
    description: "Regular flow during your period",
    analysis:
      "Cranberry-colored blood is typical during a regular flow. It's slightly darker than bright red as it's been in the uterus a bit longer.",
    recommendation: "This is normal menstrual blood. No specific action needed.",
    concern: false,
  },
  {
    id: "dark-red",
    name: "Dark Red",
    color: "#7f1d1d",
    description: "Blood that has oxidized longer",
    analysis:
      "Dark red blood has been in the uterus longer and has had time to oxidize. This is common toward the end of your period or with a slower flow.",
    recommendation: "This is normal, especially toward the end of your period.",
    concern: false,
  },
  {
    id: "brown",
    name: "Brown",
    color: "#78350f",
    description: "Old blood or spotting",
    analysis:
      "Brown blood is older blood that has had time to oxidize. It's common at the beginning or end of your period, or with spotting between periods.",
    recommendation:
      "Usually normal at the beginning or end of your period. If it persists throughout your entire period or occurs frequently between periods, consider consulting your healthcare provider.",
    concern: false,
  },
  {
    id: "black",
    name: "Black",
    color: "#171717",
    description: "Very old blood",
    analysis:
      "Black or very dark blood is blood that has been in the uterus for a longer time and has oxidized significantly. It may appear at the beginning or end of your period.",
    recommendation:
      "Often normal at the start of your period (old blood from the previous cycle) or at the very end. If accompanied by a foul smell or persistent throughout your period, consult your healthcare provider.",
    concern: false,
  },
  {
    id: "orange",
    name: "Orange",
    color: "#ea580c",
    description: "Blood mixed with cervical fluid",
    analysis: "Orange-tinged blood may indicate blood mixed with cervical fluid or, in some cases, an infection.",
    recommendation:
      "If accompanied by unusual discharge, itching, or a foul odor, consult your healthcare provider as this could indicate an infection.",
    concern: true,
  },
  {
    id: "pink",
    name: "Pink",
    color: "#ec4899",
    description: "Blood diluted with cervical fluid",
    analysis:
      "Pink blood is often menstrual blood diluted with cervical fluid. It can appear at the beginning or end of your period, or with spotting.",
    recommendation:
      "Usually normal at the beginning or end of your period. If it occurs with irregular spotting or after intercourse, consider consulting your healthcare provider.",
    concern: false,
  },
  {
    id: "gray",
    name: "Gray",
    color: "#6b7280",
    description: "Possibly indicating an infection",
    analysis:
      "Gray or off-white discharge mixed with blood can indicate an infection such as bacterial vaginosis or other conditions.",
    recommendation:
      "Consult your healthcare provider promptly, especially if accompanied by unusual odor, itching, or discomfort.",
    concern: true,
  },
]

export function PeriodColorAnalyzer() {
  const [selectedColor, setSelectedColor] = useState<string | null>(null)
  const [showResults, setShowResults] = useState(false)

  const selectedColorData = periodColors.find((color) => color.id === selectedColor)

  const handleColorSelect = (colorId: string) => {
    setSelectedColor(colorId)
    setShowResults(false)
  }

  const handleAnalyze = () => {
    setShowResults(true)
  }

  const handleSaveToLog = () => {
    if (!selectedColorData) return

    try {
      // Get existing health data
      const healthDataStr = localStorage.getItem("wombix_health_data")
      const healthData = healthDataStr ? JSON.parse(healthDataStr) : { symptoms: [], logs: [] }

      // Add new log with period color
      const newLog = {
        date: new Date().toISOString(),
        symptoms: ["Menstruation"],
        notes: `Period color: ${selectedColorData.name}. ${selectedColorData.analysis}`,
        periodColor: selectedColorData.id,
      }

      healthData.logs.unshift(newLog)

      // Save updated health data
      localStorage.setItem("wombix_health_data", JSON.stringify(healthData))

      // Show confirmation
      alert("Period color information saved to your health log!")
    } catch (error) {
      console.error("Error saving period color data:", error)
      alert("There was an error saving your data. Please try again.")
    }
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Period Color Analyzer</CardTitle>
        <CardDescription>
          Track and analyze your menstrual blood color to better understand your cycle health
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div>
          <h3 className="text-lg font-medium mb-3">Select Your Period Color</h3>
          <p className="text-sm text-gray-500 mb-4">
            Choose the color that most closely matches your menstrual blood today:
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {periodColors.map((color) => (
              <Button
                key={color.id}
                variant="outline"
                className={`h-auto py-3 px-4 flex flex-col items-center gap-2 border-2 transition-all ${
                  selectedColor === color.id ? "border-pink-500 ring-2 ring-pink-200" : "border-gray-200"
                }`}
                onClick={() => handleColorSelect(color.id)}
              >
                <div
                  className="w-8 h-8 rounded-full"
                  style={{ backgroundColor: color.color }}
                  aria-label={color.name}
                />
                <span className="text-sm font-medium">{color.name}</span>
              </Button>
            ))}
          </div>
        </div>

        {selectedColor && !showResults && (
          <div className="flex justify-center">
            <Button onClick={handleAnalyze} className="bg-pink-600 hover:bg-pink-700">
              Analyze Color
            </Button>
          </div>
        )}

        {showResults && selectedColorData && (
          <Tabs defaultValue="analysis" className="w-full">
            <TabsList className="w-full">
              <TabsTrigger value="analysis" className="flex-1">
                Analysis
              </TabsTrigger>
              <TabsTrigger value="recommendations" className="flex-1">
                Recommendations
              </TabsTrigger>
            </TabsList>
            <TabsContent value="analysis" className="space-y-4 pt-4">
              <div className="flex items-center gap-3 mb-4">
                <div
                  className="w-10 h-10 rounded-full flex-shrink-0"
                  style={{ backgroundColor: selectedColorData.color }}
                />
                <div>
                  <h3 className="font-medium">{selectedColorData.name}</h3>
                  <p className="text-sm text-gray-500">{selectedColorData.description}</p>
                </div>
              </div>

              <Alert variant={selectedColorData.concern ? "destructive" : "default"}>
                {selectedColorData.concern ? (
                  <AlertTriangleIcon className="h-4 w-4" />
                ) : (
                  <InfoIcon className="h-4 w-4" />
                )}
                <AlertTitle>{selectedColorData.concern ? "Attention Needed" : "Normal Variation"}</AlertTitle>
                <AlertDescription>{selectedColorData.analysis}</AlertDescription>
              </Alert>
            </TabsContent>

            <TabsContent value="recommendations" className="space-y-4 pt-4">
              <Alert variant={selectedColorData.concern ? "destructive" : "default"}>
                <AlertTitle>What This Means For You</AlertTitle>
                <AlertDescription>{selectedColorData.recommendation}</AlertDescription>
              </Alert>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-medium mb-2">Track Changes Over Time</h4>
                <p className="text-sm text-gray-600 mb-3">
                  Monitoring your period color throughout your cycle can provide valuable insights into your
                  reproductive health. Save this information to your health log to track patterns over time.
                </p>
                <Button onClick={handleSaveToLog} className="w-full bg-pink-600 hover:bg-pink-700">
                  Save to My Health Log
                </Button>
              </div>

              {selectedColorData.concern && (
                <div className="bg-red-50 p-4 rounded-lg border border-red-200">
                  <h4 className="font-medium text-red-800 mb-2">When to Consult a Healthcare Provider</h4>
                  <ul className="text-sm text-red-700 list-disc pl-5 space-y-1">
                    <li>If this color persists for more than two cycles</li>
                    <li>If accompanied by unusual odor, itching, or pain</li>
                    <li>If you experience heavy bleeding that soaks through a pad/tampon every hour</li>
                    <li>If you have severe pelvic pain</li>
                    <li>If you have fever or feel unwell</li>
                  </ul>
                </div>
              )}
            </TabsContent>
          </Tabs>
        )}
      </CardContent>
      <CardFooter className="flex justify-between border-t pt-6">
        <p className="text-xs text-gray-500">
          Note: This tool provides general information and is not a substitute for professional medical advice.
        </p>
      </CardFooter>
    </Card>
  )
}
