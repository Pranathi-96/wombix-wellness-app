"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Search } from "lucide-react"
import { Input } from "@/components/ui/input"

interface SymptomTrackerProps {
  selectedSymptoms: string[]
  onSelectSymptom: (symptom: string) => void
}

const symptomCategories = [
  {
    name: "Physical",
    symptoms: [
      "Headache",
      "Cramps",
      "Bloating",
      "Fatigue",
      "Breast Tenderness",
      "Back Pain",
      "Nausea",
      "Dizziness",
      "Hot Flashes",
      "Insomnia",
      "Joint Pain",
      "Swelling",
    ],
  },
  {
    name: "Emotional",
    symptoms: [
      "Mood Swings",
      "Irritability",
      "Anxiety",
      "Depression",
      "Overwhelm",
      "Brain Fog",
      "Low Motivation",
      "Stress",
      "Crying Spells",
      "Anger",
      "Social Withdrawal",
    ],
  },
  {
    name: "Digestive",
    symptoms: [
      "Constipation",
      "Diarrhea",
      "Gas",
      "Indigestion",
      "Acid Reflux",
      "Stomach Pain",
      "Food Cravings",
      "Appetite Changes",
      "Nausea",
    ],
  },
  {
    name: "Skin",
    symptoms: ["Acne", "Dry Skin", "Rash", "Itching", "Eczema Flare", "Oily Skin", "Hair Loss", "Excessive Sweating"],
  },
  {
    name: "Cycle",
    symptoms: [
      "Light Flow",
      "Heavy Flow",
      "Spotting",
      "Clotting",
      "Irregular Period",
      "Missed Period",
      "Early Period",
      "Vaginal Dryness",
      "Discharge Changes",
    ],
  },
]

export function SymptomTracker({ selectedSymptoms, onSelectSymptom }: SymptomTrackerProps) {
  const [activeCategory, setActiveCategory] = useState("Physical")
  const [searchQuery, setSearchQuery] = useState("")

  const allSymptoms = symptomCategories.flatMap((category) => category.symptoms)

  const filteredSymptoms = searchQuery
    ? allSymptoms.filter((symptom) => symptom.toLowerCase().includes(searchQuery.toLowerCase()))
    : symptomCategories.find((category) => category.name === activeCategory)?.symptoms || []

  return (
    <div className="space-y-4">
      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
        <Input
          placeholder="Search symptoms..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10 border-gray-300 focus-visible:ring-pink-500"
        />
      </div>

      {!searchQuery && (
        <Tabs defaultValue="Physical" onValueChange={setActiveCategory}>
          <TabsList className="w-full flex overflow-auto">
            {symptomCategories.map((category) => (
              <TabsTrigger key={category.name} value={category.name} className="flex-1">
                {category.name}
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>
      )}

      <Card className="border-pink-200">
        <CardContent className="pt-6">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
            {filteredSymptoms.map((symptom) => (
              <Button
                key={symptom}
                variant={selectedSymptoms.includes(symptom) ? "default" : "outline"}
                className={`justify-start h-auto py-2 transition-all ${
                  selectedSymptoms.includes(symptom)
                    ? "bg-pink-600 hover:bg-pink-700 text-white"
                    : "hover:border-pink-300 hover:bg-pink-50"
                }`}
                onClick={() => onSelectSymptom(symptom)}
              >
                {symptom}
              </Button>
            ))}
            {filteredSymptoms.length === 0 && (
              <div className="col-span-full py-8 text-center text-gray-500">
                {searchQuery ? "No symptoms match your search" : "No symptoms in this category"}
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <div>
        <h3 className="text-sm font-medium mb-2">Selected Symptoms ({selectedSymptoms.length})</h3>
        <div className="flex flex-wrap gap-2">
          {selectedSymptoms.length === 0 ? (
            <p className="text-sm text-gray-500">No symptoms selected</p>
          ) : (
            selectedSymptoms.map((symptom) => (
              <Badge
                key={symptom}
                className="bg-pink-100 hover:bg-pink-200 text-pink-800 px-3 py-1 rounded-full text-sm flex items-center"
              >
                {symptom}
                <button
                  className="ml-2 text-pink-800 hover:text-pink-900"
                  onClick={(e) => {
                    e.preventDefault()
                    onSelectSymptom(symptom)
                  }}
                >
                  ×
                </button>
              </Badge>
            ))
          )}
        </div>
      </div>
    </div>
  )
}
