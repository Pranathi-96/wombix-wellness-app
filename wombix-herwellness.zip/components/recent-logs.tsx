"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export function RecentLogs() {
  const [logs, setLogs] = useState<any[]>([])

  useEffect(() => {
    // Get health data from localStorage
    const healthDataStr = localStorage.getItem("wombix_health_data")
    if (healthDataStr) {
      const healthData = JSON.parse(healthDataStr)
      setLogs(healthData.logs || [])
    }
  }, [])

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
    })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Health Logs</CardTitle>
        <CardDescription>Your most recent symptom tracking entries</CardDescription>
      </CardHeader>
      <CardContent>
        {logs.length === 0 ? (
          <div className="text-center py-6">
            <p className="text-gray-500 mb-4">No health logs yet</p>
            <Button>Start Tracking</Button>
          </div>
        ) : (
          <div className="space-y-4">
            {logs.slice(0, 5).map((log, index) => (
              <div key={index} className="flex items-start gap-4 pb-4 border-b last:border-0 last:pb-0">
                <div className="min-w-[60px] text-center">
                  <div className="text-lg font-bold">{formatDate(log.date)}</div>
                </div>
                <div>
                  <div className="flex flex-wrap gap-1 mb-2">
                    {log.symptoms.map((symptom: string, i: number) => (
                      <span key={i} className="text-xs px-2 py-1 bg-pink-100 text-pink-800 rounded-full">
                        {symptom}
                      </span>
                    ))}
                  </div>
                  {log.notes && <p className="text-sm text-gray-500 line-clamp-2">{log.notes}</p>}
                </div>
              </div>
            ))}

            {logs.length > 5 && (
              <div className="flex justify-center">
                <Button variant="link" className="text-pink-600">
                  View All Logs
                </Button>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
