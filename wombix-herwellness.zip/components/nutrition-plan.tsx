"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { InfoIcon, CheckCircle2 } from "lucide-react"
import { Button } from "@/components/ui/button"

export function NutritionPlan() {
  const [healthData, setHealthData] = useState<any>(null)
  const [userData, setUserData] = useState<any>(null)
  const [activeDay, setActiveDay] = useState("monday")

  useEffect(() => {
    // Get health data from localStorage
    const healthDataStr = localStorage.getItem("wombix_health_data")
    if (healthDataStr) {
      setHealthData(JSON.parse(healthDataStr))
    }

    // Get user data from localStorage
    const userDataStr = localStorage.getItem("wombix_user")
    if (userDataStr) {
      setUserData(JSON.parse(userDataStr))
    }
  }, [])

  if (!healthData || !userData) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Personalized Nutrition Plan</CardTitle>
          <CardDescription>Loading your nutrition recommendations...</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-6">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-pink-600"></div>
          </div>
        </CardContent>
      </Card>
    )
  }

  // Get conditions for personalization
  const conditions = userData.conditions || []

  const weeklyMealPlan = {
    monday: {
      breakfast: {
        title: "Anti-Inflammatory Smoothie Bowl",
        description: "Blueberry and spinach smoothie topped with flaxseeds, chia seeds, and walnuts",
        image: "/placeholder.svg?height=100&width=150",
        benefits: ["Rich in antioxidants", "Omega-3 fatty acids", "Fiber"],
      },
      lunch: {
        title: "Mediterranean Quinoa Salad",
        description: "Quinoa with cucumber, tomatoes, olives, feta, and lemon-olive oil dressing",
        image: "/placeholder.svg?height=100&width=150",
        benefits: ["Complex carbs", "Healthy fats", "Anti-inflammatory"],
      },
      dinner: {
        title: "Baked Salmon with Roasted Vegetables",
        description: "Wild-caught salmon with roasted Brussels sprouts, sweet potatoes, and herbs",
        image: "/placeholder.svg?height=100&width=150",
        benefits: ["Omega-3 rich", "High-quality protein", "Diverse nutrients"],
      },
      snacks: ["Apple slices with almond butter", "Greek yogurt with berries", "Handful of mixed nuts"],
    },
    tuesday: {
      breakfast: {
        title: "Hormone-Balancing Breakfast Bowl",
        description: "Overnight oats with cinnamon, almond milk, pumpkin seeds, and berries",
        image: "/placeholder.svg?height=100&width=150",
        benefits: ["Zinc for hormone production", "Slow-release carbs", "Antioxidants"],
      },
      lunch: {
        title: "Lentil and Vegetable Soup",
        description: "Hearty lentil soup with carrots, celery, spinach, and turmeric",
        image: "/placeholder.svg?height=100&width=150",
        benefits: ["Plant-based protein", "Fiber", "Anti-inflammatory spices"],
      },
      dinner: {
        title: "Turkey and Vegetable Stir-Fry",
        description: "Lean turkey with broccoli, bell peppers, and snap peas in ginger sauce",
        image: "/placeholder.svg?height=100&width=150",
        benefits: ["Lean protein", "Cruciferous vegetables", "Low glycemic"],
      },
      snacks: ["Hummus with vegetable sticks", "Pear with a small piece of cheese", "Edamame"],
    },
    wednesday: {
      breakfast: {
        title: "Protein-Rich Egg Muffins",
        description: "Baked egg muffins with spinach, bell peppers, and a sprinkle of feta",
        image: "/placeholder.svg?height=100&width=150",
        benefits: ["Complete protein", "Choline for liver health", "B vitamins"],
      },
      lunch: {
        title: "Chickpea and Avocado Wrap",
        description: "Whole grain wrap with mashed chickpeas, avocado, greens, and tahini",
        image: "/placeholder.svg?height=100&width=150",
        benefits: ["Healthy fats", "Plant protein", "Fiber"],
      },
      dinner: {
        title: "Herb-Roasted Chicken with Vegetables",
        description: "Roasted chicken breast with rosemary, thyme, and root vegetables",
        image: "/placeholder.svg?height=100&width=150",
        benefits: ["Quality protein", "Diverse nutrients", "Herbs with medicinal properties"],
      },
      snacks: ["Trail mix with nuts and dark chocolate", "Celery with almond butter", "Coconut yogurt with berries"],
    },
    thursday: {
      breakfast: {
        title: "Green Protein Smoothie",
        description: "Spinach, avocado, plant protein, and almond milk smoothie",
        image: "/placeholder.svg?height=100&width=150",
        benefits: ["Leafy greens", "Healthy fats", "Easy to digest"],
      },
      lunch: {
        title: "Wild Rice and Salmon Bowl",
        description: "Wild rice with flaked salmon, cucumber, avocado, and sesame seeds",
        image: "/placeholder.svg?height=100&width=150",
        benefits: ["Omega-3 fatty acids", "Complex carbs", "Healthy fats"],
      },
      dinner: {
        title: "Lentil and Vegetable Curry",
        description: "Red lentil curry with cauliflower, spinach, and anti-inflammatory spices",
        image: "/placeholder.svg?height=100&width=150",
        benefits: ["Plant protein", "Turmeric and ginger", "Fiber"],
      },
      snacks: ["Roasted chickpeas", "Apple with cinnamon", "Small handful of walnuts"],
    },
    friday: {
      breakfast: {
        title: "Chia Seed Pudding",
        description: "Chia seeds soaked in almond milk with vanilla, topped with berries",
        image: "/placeholder.svg?height=100&width=150",
        benefits: ["Omega-3 fatty acids", "Fiber", "Calcium"],
      },
      lunch: {
        title: "Mediterranean Plate",
        description: "Hummus, olives, cucumber, cherry tomatoes, feta, and whole grain pita",
        image: "/placeholder.svg?height=100&width=150",
        benefits: ["Balanced macronutrients", "Healthy fats", "Diverse plant foods"],
      },
      dinner: {
        title: "Baked White Fish with Quinoa",
        description: "Lemon herb white fish with quinoa and steamed broccoli",
        image: "/placeholder.svg?height=100&width=150",
        benefits: ["Lean protein", "Complete protein grain", "Cruciferous vegetables"],
      },
      snacks: ["Guacamole with vegetable sticks", "Peach with cottage cheese", "Seaweed snacks"],
    },
    saturday: {
      breakfast: {
        title: "Veggie Frittata",
        description: "Baked eggs with zucchini, tomatoes, onions, and a sprinkle of goat cheese",
        image: "/placeholder.svg?height=100&width=150",
        benefits: ["Quality protein", "Diverse vegetables", "Healthy fats"],
      },
      lunch: {
        title: "Hearty Vegetable Soup",
        description: "Vegetable soup with white beans, kale, carrots, and celery",
        image: "/placeholder.svg?height=100&width=150",
        benefits: ["Plant protein", "Fiber", "Hydrating"],
      },
      dinner: {
        title: "Grass-Fed Beef Stir-Fry",
        description: "Lean beef strips with bok choy, mushrooms, and brown rice",
        image: "/placeholder.svg?height=100&width=150",
        benefits: ["Iron-rich", "B vitamins", "Complex carbs"],
      },
      snacks: ["Dark chocolate (70%+ cacao)", "Pear with almond butter", "Handful of pistachios"],
    },
    sunday: {
      breakfast: {
        title: "Sweet Potato and Egg Hash",
        description: "Sweet potato hash with eggs, bell peppers, and avocado",
        image: "/placeholder.svg?height=100&width=150",
        benefits: ["Vitamin A", "Quality protein", "Healthy carbs"],
      },
      lunch: {
        title: "Tuna Salad Lettuce Wraps",
        description: "Olive oil tuna salad with celery and herbs in romaine lettuce cups",
        image: "/placeholder.svg?height=100&width=150",
        benefits: ["Omega-3 fatty acids", "Lean protein", "Low calorie"],
      },
      dinner: {
        title: "Roasted Vegetable Buddha Bowl",
        description: "Roasted vegetables with quinoa, chickpeas, and tahini dressing",
        image: "/placeholder.svg?height=100&width=150",
        benefits: ["Plant-based protein", "Fiber-rich", "Diverse nutrients"],
      },
      snacks: ["Rice cakes with almond butter", "Orange slices", "Small handful of cashews"],
    },
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Personalized Nutrition Plan</CardTitle>
        <CardDescription>Dietary recommendations based on your symptoms and health conditions</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="meal-plan">
          <TabsList className="mb-4">
            <TabsTrigger value="meal-plan">Weekly Meal Plan</TabsTrigger>
            <TabsTrigger value="guidelines">Nutrition Guidelines</TabsTrigger>
            <TabsTrigger value="foods-list">Foods List</TabsTrigger>
          </TabsList>

          <TabsContent value="meal-plan" className="space-y-6">
            <div className="bg-gradient-to-r from-pink-50 to-purple-50 p-4 rounded-lg mb-6">
              <h3 className="text-lg font-medium mb-2">Your Personalized Weekly Meal Plan</h3>
              <p className="text-gray-600">
                This meal plan is tailored to your health profile and designed to support hormonal balance, reduce
                inflammation, and provide essential nutrients for your wellbeing.
              </p>
            </div>

            <div className="space-y-6">
              <div className="flex overflow-x-auto pb-2 mb-4 gap-2">
                {Object.keys(weeklyMealPlan).map((day) => (
                  <Button
                    key={day}
                    variant={activeDay === day ? "default" : "outline"}
                    className={`rounded-full px-4 py-2 ${
                      activeDay === day ? "bg-pink-600 hover:bg-pink-700" : "hover:bg-pink-50 hover:text-pink-600"
                    }`}
                    onClick={() => setActiveDay(day)}
                  >
                    {day.charAt(0).toUpperCase() + day.slice(1)}
                  </Button>
                ))}
              </div>

              <div className="grid gap-6 md:grid-cols-3">
                <Card>
                  <CardHeader className="pb-2 bg-gradient-to-r from-pink-500/5 to-purple-500/5">
                    <CardTitle className="text-base">Breakfast</CardTitle>
                  </CardHeader>
                  <CardContent className="pt-4">
                    <div className="flex gap-3 mb-3">
                      <div className="relative w-16 h-16 rounded overflow-hidden flex-shrink-0">
                        <Image
                          src={
                            weeklyMealPlan[activeDay as keyof typeof weeklyMealPlan].breakfast.image ||
                            "/placeholder.svg"
                          }
                          alt="Breakfast"
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div>
                        <h4 className="font-medium text-sm">
                          {weeklyMealPlan[activeDay as keyof typeof weeklyMealPlan].breakfast.title}
                        </h4>
                        <p className="text-xs text-gray-500">
                          {weeklyMealPlan[activeDay as keyof typeof weeklyMealPlan].breakfast.description}
                        </p>
                      </div>
                    </div>
                    <div className="mt-3">
                      <p className="text-xs font-medium text-gray-600 mb-1">Benefits:</p>
                      <div className="flex flex-wrap gap-1">
                        {weeklyMealPlan[activeDay as keyof typeof weeklyMealPlan].breakfast.benefits.map(
                          (benefit, i) => (
                            <div key={i} className="flex items-center text-xs text-gray-600">
                              <CheckCircle2 className="h-3 w-3 text-green-500 mr-1" />
                              <span>{benefit}</span>
                            </div>
                          ),
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2 bg-gradient-to-r from-pink-500/5 to-purple-500/5">
                    <CardTitle className="text-base">Lunch</CardTitle>
                  </CardHeader>
                  <CardContent className="pt-4">
                    <div className="flex gap-3 mb-3">
                      <div className="relative w-16 h-16 rounded overflow-hidden flex-shrink-0">
                        <Image
                          src={
                            weeklyMealPlan[activeDay as keyof typeof weeklyMealPlan].lunch.image || "/placeholder.svg"
                          }
                          alt="Lunch"
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div>
                        <h4 className="font-medium text-sm">
                          {weeklyMealPlan[activeDay as keyof typeof weeklyMealPlan].lunch.title}
                        </h4>
                        <p className="text-xs text-gray-500">
                          {weeklyMealPlan[activeDay as keyof typeof weeklyMealPlan].lunch.description}
                        </p>
                      </div>
                    </div>
                    <div className="mt-3">
                      <p className="text-xs font-medium text-gray-600 mb-1">Benefits:</p>
                      <div className="flex flex-wrap gap-1">
                        {weeklyMealPlan[activeDay as keyof typeof weeklyMealPlan].lunch.benefits.map((benefit, i) => (
                          <div key={i} className="flex items-center text-xs text-gray-600">
                            <CheckCircle2 className="h-3 w-3 text-green-500 mr-1" />
                            <span>{benefit}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2 bg-gradient-to-r from-pink-500/5 to-purple-500/5">
                    <CardTitle className="text-base">Dinner</CardTitle>
                  </CardHeader>
                  <CardContent className="pt-4">
                    <div className="flex gap-3 mb-3">
                      <div className="relative w-16 h-16 rounded overflow-hidden flex-shrink-0">
                        <Image
                          src={
                            weeklyMealPlan[activeDay as keyof typeof weeklyMealPlan].dinner.image || "/placeholder.svg"
                          }
                          alt="Dinner"
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div>
                        <h4 className="font-medium text-sm">
                          {weeklyMealPlan[activeDay as keyof typeof weeklyMealPlan].dinner.title}
                        </h4>
                        <p className="text-xs text-gray-500">
                          {weeklyMealPlan[activeDay as keyof typeof weeklyMealPlan].dinner.description}
                        </p>
                      </div>
                    </div>
                    <div className="mt-3">
                      <p className="text-xs font-medium text-gray-600 mb-1">Benefits:</p>
                      <div className="flex flex-wrap gap-1">
                        {weeklyMealPlan[activeDay as keyof typeof weeklyMealPlan].dinner.benefits.map((benefit, i) => (
                          <div key={i} className="flex items-center text-xs text-gray-600">
                            <CheckCircle2 className="h-3 w-3 text-green-500 mr-1" />
                            <span>{benefit}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader className="pb-2 bg-gradient-to-r from-pink-500/5 to-purple-500/5">
                  <CardTitle className="text-base">Snacks</CardTitle>
                </CardHeader>
                <CardContent className="pt-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {weeklyMealPlan[activeDay as keyof typeof weeklyMealPlan].snacks.map((snack, i) => (
                      <div key={i} className="flex items-center gap-2">
                        <div className="rounded-full bg-green-100 p-1 flex-shrink-0">
                          <CheckCircle2 className="h-4 w-4 text-green-600" />
                        </div>
                        <span className="text-sm">{snack}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {conditions.includes("PCOS (Polycystic Ovary Syndrome)") && (
                <Alert className="bg-blue-50 border-blue-200">
                  <InfoIcon className="h-4 w-4 text-blue-600" />
                  <AlertTitle className="text-blue-800">PCOS-Specific Recommendations</AlertTitle>
                  <AlertDescription className="text-blue-700">
                    This meal plan is designed to help manage insulin resistance with low glycemic index foods, adequate
                    protein, and anti-inflammatory ingredients. The balanced meals help maintain stable blood sugar
                    levels throughout the day.
                  </AlertDescription>
                </Alert>
              )}

              {conditions.includes("Endometriosis") && (
                <Alert className="bg-purple-50 border-purple-200">
                  <InfoIcon className="h-4 w-4 text-purple-600" />
                  <AlertTitle className="text-purple-800">Endometriosis-Specific Recommendations</AlertTitle>
                  <AlertDescription className="text-purple-700">
                    This meal plan emphasizes anti-inflammatory foods and omega-3 fatty acids to help manage
                    endometriosis-related inflammation. It minimizes foods that may trigger inflammation such as
                    processed foods, excessive red meat, and refined sugars.
                  </AlertDescription>
                </Alert>
              )}
            </div>
          </TabsContent>

          <TabsContent value="guidelines" className="space-y-4">
            <Alert>
              <InfoIcon className="h-4 w-4" />
              <AlertTitle>Personalized for Your Health Profile</AlertTitle>
              <AlertDescription>
                This nutrition plan is tailored to your specific symptoms and health conditions. Adjustments may be
                needed as your health changes.
              </AlertDescription>
            </Alert>

            <div className="space-y-4">
              <h3 className="text-lg font-medium">Key Nutritional Principles</h3>
              <div className="grid gap-4 md:grid-cols-2">
                <div className="flex flex-col items-center p-4 border rounded-lg">
                  <div className="rounded-full bg-green-100 p-3 mb-3">
                    <Image src="/anti-inflammatory-icon.png" alt="Anti-inflammatory" width={24} height={24} />
                  </div>
                  <h4 className="font-medium text-center">Anti-Inflammatory Focus</h4>
                  <p className="text-sm text-center text-gray-500 mt-2">
                    Emphasize foods that reduce inflammation to help manage pain and hormonal symptoms.
                  </p>
                </div>

                <div className="flex flex-col items-center p-4 border rounded-lg">
                  <div className="rounded-full bg-blue-100 p-3 mb-3">
                    <Image src="/hormone-balance-icon.png" alt="Hormone Balance" width={24} height={24} />
                  </div>
                  <h4 className="font-medium text-center">Hormone Balance</h4>
                  <p className="text-sm text-center text-gray-500 mt-2">
                    Include foods that support healthy hormone production and metabolism.
                  </p>
                </div>

                <div className="flex flex-col items-center p-4 border rounded-lg">
                  <div className="rounded-full bg-purple-100 p-3 mb-3">
                    <Image src="/blood-sugar-icon.png" alt="Blood Sugar" width={24} height={24} />
                  </div>
                  <h4 className="font-medium text-center">Blood Sugar Regulation</h4>
                  <p className="text-sm text-center text-gray-500 mt-2">
                    Maintain stable blood sugar levels to reduce hormonal fluctuations and cravings.
                  </p>
                </div>

                <div className="flex flex-col items-center p-4 border rounded-lg">
                  <div className="rounded-full bg-yellow-100 p-3 mb-3">
                    <Image src="/gut-health-icon.png" alt="Gut Health" width={24} height={24} />
                  </div>
                  <h4 className="font-medium text-center">Gut Health Support</h4>
                  <p className="text-sm text-center text-gray-500 mt-2">
                    Promote a healthy microbiome to improve hormone metabolism and immune function.
                  </p>
                </div>
              </div>

              {conditions.includes("PCOS (Polycystic Ovary Syndrome)") && (
                <div className="mt-6">
                  <h3 className="text-lg font-medium">PCOS-Specific Recommendations</h3>
                  <ul className="list-disc pl-5 space-y-2 text-gray-700 mt-2">
                    <li>Focus on low glycemic index foods to manage insulin resistance</li>
                    <li>Include adequate protein with each meal to promote satiety</li>
                    <li>Incorporate anti-inflammatory spices like turmeric and cinnamon</li>
                    <li>Consider intermittent fasting approaches (consult your healthcare provider first)</li>
                    <li>Limit dairy products, which may exacerbate hormonal acne</li>
                  </ul>
                </div>
              )}

              {conditions.includes("Endometriosis") && (
                <div className="mt-6">
                  <h3 className="text-lg font-medium">Endometriosis-Specific Recommendations</h3>
                  <ul className="list-disc pl-5 space-y-2 text-gray-700 mt-2">
                    <li>Strictly limit inflammatory foods like processed meats and trans fats</li>
                    <li>Emphasize omega-3 rich foods like fatty fish, walnuts, and flaxseeds</li>
                    <li>Consider reducing or eliminating gluten and dairy to assess sensitivity</li>
                    <li>Include cruciferous vegetables to support estrogen metabolism</li>
                    <li>Incorporate anti-inflammatory herbs like ginger and turmeric</li>
                  </ul>
                </div>
              )}

              <div className="mt-6">
                <h3 className="text-lg font-medium">Hydration Guidelines</h3>
                <p className="text-gray-500 mt-2">
                  Proper hydration is essential for hormone balance, detoxification, and overall health.
                </p>
                <ul className="list-disc pl-5 space-y-2 text-gray-700 mt-2">
                  <li>Aim for at least 2-3 liters of water daily</li>
                  <li>Increase intake during your period to replace fluid loss</li>
                  <li>Consider herbal teas like peppermint (for bloating) and chamomile (for relaxation)</li>
                  <li>Limit caffeine and alcohol, which can disrupt hormone balance</li>
                </ul>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="foods-list" className="space-y-4">
            <div className="grid gap-6 md:grid-cols-2">
              <div>
                <h3 className="text-lg font-medium mb-3">Foods to Include</h3>
                <Card className="h-full">
                  <CardContent className="pt-6">
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-medium text-pink-600">Anti-Inflammatory Foods</h4>
                        <ul className="list-disc pl-5 space-y-1 text-sm mt-2">
                          <li>Fatty fish (salmon, mackerel, sardines)</li>
                          <li>Leafy greens (spinach, kale, arugula)</li>
                          <li>Berries (blueberries, strawberries, raspberries)</li>
                          <li>Olive oil</li>
                          <li>Turmeric and ginger</li>
                          <li>Nuts (walnuts, almonds)</li>
                          <li>Seeds (flax, chia, pumpkin)</li>
                        </ul>
                      </div>

                      <div>
                        <h4 className="font-medium text-pink-600">Hormone-Supporting Foods</h4>
                        <ul className="list-disc pl-5 space-y-1 text-sm mt-2">
                          <li>Cruciferous vegetables (broccoli, cauliflower, Brussels sprouts)</li>
                          <li>Avocados</li>
                          <li>Eggs</li>
                          <li>Legumes (lentils, chickpeas, beans)</li>
                          <li>Seaweed and sea vegetables</li>
                          <li>Fermented foods (sauerkraut, kimchi, kefir)</li>
                          <li>Quality proteins (organic poultry, grass-fed beef, wild fish)</li>
                        </ul>
                      </div>

                      <div>
                        <h4 className="font-medium text-pink-600">Blood Sugar Balancing Foods</h4>
                        <ul className="list-disc pl-5 space-y-1 text-sm mt-2">
                          <li>Cinnamon</li>
                          <li>Apple cider vinegar</li>
                          <li>Complex carbohydrates (sweet potatoes, quinoa, brown rice)</li>
                          <li>Protein-rich foods</li>
                          <li>Chromium-rich foods (broccoli, grapes, potatoes)</li>
                          <li>Magnesium-rich foods (dark chocolate, avocados, nuts)</li>
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div>
                <h3 className="text-lg font-medium mb-3">Foods to Limit or Avoid</h3>
                <Card className="h-full">
                  <CardContent className="pt-6">
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-medium text-pink-600">Inflammatory Foods</h4>
                        <ul className="list-disc pl-5 space-y-1 text-sm mt-2">
                          <li>Processed meats (bacon, sausage, deli meats)</li>
                          <li>Refined oils (vegetable, canola, soybean)</li>
                          <li>Trans fats and fried foods</li>
                          <li>Refined sugar and high-fructose corn syrup</li>
                          <li>Artificial sweeteners and additives</li>
                          <li>Excessive alcohol</li>
                        </ul>
                      </div>

                      <div>
                        <h4 className="font-medium text-pink-600">Hormone-Disrupting Foods</h4>
                        <ul className="list-disc pl-5 space-y-1 text-sm mt-2">
                          <li>Conventional dairy products</li>
                          <li>Non-organic meat and poultry</li>
                          <li>Soy products (especially processed soy)</li>
                          <li>Foods in plastic packaging</li>
                          <li>Pesticide-heavy produce (non-organic strawberries, spinach, etc.)</li>
                          <li>Excessive caffeine</li>
                        </ul>
                      </div>

                      <div>
                        <h4 className="font-medium text-pink-600">Common Sensitivities</h4>
                        <ul className="list-disc pl-5 space-y-1 text-sm mt-2">
                          <li>Gluten</li>
                          <li>Dairy</li>
                          <li>Eggs (for some individuals)</li>
                          <li>Nightshades (tomatoes, peppers, eggplant)</li>
                          <li>Corn</li>
                          <li>Artificial food colorings and preservatives</li>
                        </ul>
                        <p className="text-xs text-gray-500 mt-2">
                          Note: Individual sensitivities vary. Consider an elimination diet under professional guidance
                          to identify your specific triggers.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            <div className="bg-pink-50 p-4 rounded-lg mt-6">
              <p className="text-sm text-pink-800">
                <span className="font-medium">Important:</span> This foods list is personalized based on your reported
                symptoms and conditions. Always consult with a healthcare provider or registered dietitian before making
                significant dietary changes, especially if you have existing health conditions or are taking
                medications.
              </p>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
