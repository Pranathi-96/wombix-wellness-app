"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { InfoIcon, AlertTriangleIcon } from "lucide-react"

interface HealthSummaryProps {
  detailed?: boolean
}

export function HealthSummary({ detailed = false }: HealthSummaryProps) {
  const [healthData, setHealthData] = useState<any>(null)
  const [userData, setUserData] = useState<any>(null)

  useEffect(() => {
    // Get health data from localStorage
    const healthDataStr = localStorage.getItem("wombix_health_data")
    if (healthDataStr) {
      setHealthData(JSON.parse(healthDataStr))
    }

    // Get user data from localStorage
    const userDataStr = localStorage.getItem("wombix_user")
    if (userDataStr) {
      setUserData(JSON.parse(userDataStr))
    }
  }, [])

  if (!healthData || !userData) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Health Summary</CardTitle>
          <CardDescription>Loading your health insights...</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-6">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-pink-600"></div>
          </div>
        </CardContent>
      </Card>
    )
  }

  // Get top symptoms
  const topSymptoms = [...(healthData.symptoms || [])].sort((a, b) => b.count - a.count).slice(0, 5)

  // Generate insights based on symptoms and conditions
  const insights = generateInsights(topSymptoms, userData.conditions || [])

  return (
    <Card className={detailed ? "col-span-full" : ""}>
      <CardHeader>
        <CardTitle>Health Summary</CardTitle>
        <CardDescription>Personalized insights based on your symptoms and health data</CardDescription>
      </CardHeader>
      <CardContent>
        {detailed ? (
          <Tabs defaultValue="insights">
            <TabsList className="mb-4">
              <TabsTrigger value="insights">Insights</TabsTrigger>
              <TabsTrigger value="symptoms">Symptom Analysis</TabsTrigger>
              <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
            </TabsList>

            <TabsContent value="insights" className="space-y-4">
              {insights.map((insight, index) => (
                <Alert key={index} variant={insight.type === "warning" ? "destructive" : "default"}>
                  {insight.type === "warning" ? (
                    <AlertTriangleIcon className="h-4 w-4" />
                  ) : (
                    <InfoIcon className="h-4 w-4" />
                  )}
                  <AlertTitle>{insight.title}</AlertTitle>
                  <AlertDescription>{insight.description}</AlertDescription>
                </Alert>
              ))}
            </TabsContent>

            <TabsContent value="symptoms" className="space-y-4">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Your Top Symptoms</h3>
                <div className="grid gap-3">
                  {topSymptoms.map((symptom: any) => (
                    <div key={symptom.name} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-pink-600"></div>
                        <span>{symptom.name}</span>
                      </div>
                      <span className="text-sm text-gray-500">
                        Reported {symptom.count} {symptom.count === 1 ? "time" : "times"}
                      </span>
                    </div>
                  ))}
                </div>

                <h3 className="text-lg font-medium mt-6">Symptom Patterns</h3>
                <p className="text-gray-500">Based on your tracking data, we've identified the following patterns:</p>
                <ul className="list-disc pl-5 space-y-2 text-gray-700">
                  <li>Your symptoms tend to be most severe 2-3 days before your period</li>
                  <li>Headaches often coincide with reported stress and poor sleep</li>
                  <li>Digestive symptoms appear to improve with dietary changes</li>
                  <li>Energy levels are lowest during the first 2 days of your period</li>
                </ul>
              </div>
            </TabsContent>

            <TabsContent value="recommendations" className="space-y-4">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Medical Recommendations</h3>
                <p className="text-gray-500">Based on your symptoms and conditions, consider the following:</p>
                <ul className="list-disc pl-5 space-y-2 text-gray-700">
                  <li>Schedule a follow-up with your healthcare provider to discuss your recurring headaches</li>
                  <li>Consider testing for vitamin D and iron levels, as deficiencies can contribute to fatigue</li>
                  <li>Track your basal body temperature to better understand your ovulation patterns</li>
                  <li>Discuss hormone testing options with your doctor to evaluate potential hormonal imbalances</li>
                </ul>

                <h3 className="text-lg font-medium mt-6">Lifestyle Recommendations</h3>
                <p className="text-gray-500">These adjustments may help improve your symptoms:</p>
                <ul className="list-disc pl-5 space-y-2 text-gray-700">
                  <li>Incorporate anti-inflammatory foods like fatty fish, berries, and leafy greens</li>
                  <li>Practice stress-reduction techniques such as deep breathing or meditation</li>
                  <li>Maintain consistent sleep and wake times to regulate your hormonal cycles</li>
                  <li>Consider gentle exercise like yoga or walking during high-symptom days</li>
                  <li>Stay hydrated with at least 2 liters of water daily</li>
                </ul>

                <div className="bg-pink-50 p-4 rounded-lg mt-6">
                  <p className="text-sm text-pink-800 font-medium">
                    Remember: These recommendations are personalized based on your reported symptoms and conditions, but
                    they are not a substitute for professional medical advice. Always consult with your healthcare
                    provider before making significant changes to your health regimen.
                  </p>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        ) : (
          <div className="space-y-4">
            <div className="space-y-2">
              <h3 className="text-lg font-medium">Recent Insights</h3>
              {insights.slice(0, 2).map((insight, index) => (
                <Alert key={index} variant={insight.type === "warning" ? "destructive" : "default"}>
                  {insight.type === "warning" ? (
                    <AlertTriangleIcon className="h-4 w-4" />
                  ) : (
                    <InfoIcon className="h-4 w-4" />
                  )}
                  <AlertTitle>{insight.title}</AlertTitle>
                  <AlertDescription className="line-clamp-2">{insight.description}</AlertDescription>
                </Alert>
              ))}
            </div>

            <div className="flex justify-end">
              <Button variant="link" className="text-pink-600">
                View Full Health Analysis →
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

function generateInsights(symptoms: any[], conditions: string[]) {
  const insights = [
    {
      title: "Potential Hormonal Imbalance",
      description:
        "Your symptoms of mood swings, fatigue, and headaches may indicate hormonal fluctuations. Consider tracking these symptoms alongside your cycle to identify patterns.",
      type: "info",
    },
    {
      title: "Stress Management Needed",
      description:
        "Frequent headaches and sleep disturbances often correlate with high stress levels. Incorporating stress-reduction techniques like meditation or deep breathing exercises may help reduce these symptoms.",
      type: "info",
    },
    {
      title: "Nutritional Support Recommended",
      description:
        "Your symptoms of fatigue and digestive issues could benefit from dietary adjustments. Our nutrition plan includes anti-inflammatory foods and specific nutrients that may help address these concerns.",
      type: "info",
    },
  ]

  // Add condition-specific insights
  if (conditions.includes("PCOS (Polycystic Ovary Syndrome)")) {
    insights.push({
      title: "PCOS Management",
      description:
        "Your PCOS symptoms may be improved with regular exercise and a low-glycemic diet. Research shows that even moderate weight loss of 5-10% can help regulate hormones and improve symptoms.",
      type: "info",
    })
  }

  if (conditions.includes("Endometriosis")) {
    insights.push({
      title: "Pain Management Alert",
      description:
        "Your reported pain levels are higher than your typical pattern. Consider scheduling a follow-up with your healthcare provider if this persists for more than two cycles.",
      type: "warning",
    })
  }

  // Add symptom-specific insights
  const symptomNames = symptoms.map((s) => s.name.toLowerCase())

  if (symptomNames.includes("headache") || symptomNames.includes("migraines")) {
    insights.push({
      title: "Headache Pattern Detected",
      description:
        "Your headaches appear to follow a cyclical pattern, occurring most frequently during the luteal phase of your cycle. This may indicate hormonal headaches, which can be managed with preventative strategies.",
      type: "info",
    })
  }

  if (symptomNames.includes("fatigue") && symptomNames.includes("dizziness")) {
    insights.push({
      title: "Possible Iron Deficiency",
      description:
        "The combination of fatigue and dizziness, especially during your period, could indicate low iron levels. Consider discussing iron testing with your healthcare provider.",
      type: "warning",
    })
  }

  return insights
}
