import type React from "react"
import Link from "next/link"
import { cn } from "@/lib/utils"

export function MainNav({ className, ...props }: React.HTMLAttributes<HTMLElement>) {
  return (
    <nav className={cn("flex items-center space-x-4 lg:space-x-6", className)} {...props}>
      <Link href="/dashboard" className="text-sm font-medium transition-colors hover:text-pink-600">
        Dashboard
      </Link>
      <Link href="/track" className="text-sm font-medium text-muted-foreground transition-colors hover:text-pink-600">
        Track Health
      </Link>
      <Link
        href="/exercise"
        className="text-sm font-medium text-muted-foreground transition-colors hover:text-pink-600"
      >
        Exercise
      </Link>
      <Link
        href="/nutrition"
        className="text-sm font-medium text-muted-foreground transition-colors hover:text-pink-600"
      >
        Nutrition
      </Link>
      <Link
        href="/resources"
        className="text-sm font-medium text-muted-foreground transition-colors hover:text-pink-600"
      >
        Resources
      </Link>
    </nav>
  )
}
