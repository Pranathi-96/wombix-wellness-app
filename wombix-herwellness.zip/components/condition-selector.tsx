"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"

interface ConditionSelectorProps {
  selectedConditions: string[]
  onToggleCondition: (condition: string) => void
}

// Simplified condition categories with fewer items
const conditions = [
  {
    category: "Menstrual Health",
    items: ["PCOS (Polycystic Ovary Syndrome)", "Endometriosis", "Fibroids", "Irregular Periods"],
  },
  {
    category: "Hormonal Conditions",
    items: ["Thyroid Disorders", "Estrogen Dominance", "Perimenopause", "Menopause"],
  },
  {
    category: "Fertility & Reproductive Health",
    items: ["Trying to Conceive", "Unexplained Infertility", "Pregnancy", "Postpartum Recovery"],
  },
  {
    category: "General Health",
    items: ["Chronic Fatigue", "Digestive Issues", "Migraines", "Anxiety/Depression"],
  },
]

export function ConditionSelector({ selectedConditions, onToggleCondition }: ConditionSelectorProps) {
  const [selectedCategory, setSelectedCategory] = useState("Menstrual Health")

  const currentCategoryItems = conditions.find((c) => c.category === selectedCategory)?.items || []

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2">
        {conditions.map((category) => (
          <Button
            key={category.category}
            variant={selectedCategory === category.category ? "default" : "outline"}
            onClick={() => setSelectedCategory(category.category)}
            size="sm"
          >
            {category.category}
          </Button>
        ))}
      </div>

      <Card>
        <CardContent className="pt-6">
          <div className="grid gap-4">
            {currentCategoryItems.map((condition) => (
              <div key={condition} className="flex items-center space-x-2">
                <Checkbox
                  id={condition}
                  checked={selectedConditions.includes(condition)}
                  onCheckedChange={() => onToggleCondition(condition)}
                />
                <Label htmlFor={condition} className="cursor-pointer">
                  {condition}
                </Label>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
