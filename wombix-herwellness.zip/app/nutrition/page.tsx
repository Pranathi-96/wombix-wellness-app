"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MainNav } from "@/components/main-nav"
import { UserNav } from "@/components/user-nav"
import { NutritionPlan } from "@/components/nutrition-plan"
import { AIChatbot } from "@/components/ai-chatbot"
import { Utensils, Apple, Coffee, Salad, Search, ChevronRight, Clock } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"

export default function NutritionPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")

  useEffect(() => {
    // Check if user exists and is onboarded
    const userData = localStorage.getItem("wombix_user")
    if (!userData) {
      router.push("/login")
      return
    }

    try {
      const parsedUser = JSON.parse(userData)
      if (!parsedUser.isOnboarded) {
        router.push("/onboarding")
        return
      }

      setUser(parsedUser)
      setLoading(false)
    } catch (error) {
      console.error("Error parsing user data:", error)
      router.push("/login")
    }
  }, [router])

  const recipes = [
    {
      id: "anti-inflammatory-bowl",
      title: "Anti-Inflammatory Buddha Bowl",
      description: "A nutrient-dense bowl with turmeric roasted chickpeas, sweet potatoes, and leafy greens.",
      prepTime: "25 min",
      tags: ["Anti-Inflammatory", "PCOS-Friendly", "Vegan"],
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: "hormone-balancing-smoothie",
      title: "Hormone-Balancing Smoothie",
      description: "Creamy smoothie with avocado, flaxseeds, and berries to support hormonal health.",
      prepTime: "10 min",
      tags: ["Hormone Balance", "Quick", "Breakfast"],
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: "omega-rich-salmon",
      title: "Omega-3 Rich Salmon Plate",
      description: "Baked salmon with roasted vegetables and quinoa for essential fatty acids.",
      prepTime: "30 min",
      tags: ["Omega-3", "Protein", "Dinner"],
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: "seed-cycling-energy-balls",
      title: "Seed Cycling Energy Balls",
      description: "No-bake energy balls with specific seeds to support each phase of your cycle.",
      prepTime: "15 min",
      tags: ["Seed Cycling", "Snack", "No-Bake"],
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: "anti-inflammatory-golden-milk",
      title: "Anti-Inflammatory Golden Milk",
      description: "Warming turmeric latte with cinnamon and ginger to reduce inflammation.",
      prepTime: "8 min",
      tags: ["Anti-Inflammatory", "Beverage", "Evening"],
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: "gut-healing-breakfast",
      title: "Gut-Healing Breakfast Bowl",
      description: "Probiotic-rich breakfast with yogurt, berries, and prebiotic fiber.",
      prepTime: "12 min",
      tags: ["Gut Health", "Breakfast", "Probiotic"],
      image: "/placeholder.svg?height=200&width=300",
    },
  ]

  const filteredRecipes = searchQuery
    ? recipes.filter(
        (recipe) =>
          recipe.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          recipe.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
          recipe.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase())),
      )
    : recipes

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-pink-600 mx-auto"></div>
          <p className="mt-4 text-gray-500">Loading nutrition plan...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-br from-pink-50 to-purple-50">
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="container flex h-16 items-center px-4 md:px-6">
          <Link href="/" className="flex items-center gap-2">
            <span className="text-lg font-bold bg-gradient-to-r from-pink-600 to-purple-600 text-transparent bg-clip-text">
              Wombix_HerWellness
            </span>
          </Link>
          <MainNav className="mx-6" />
          <div className="ml-auto flex items-center space-x-4">
            <UserNav user={user} />
          </div>
        </div>
      </header>
      <main className="flex-1 p-4 md:p-6">
        <div className="container mx-auto max-w-6xl">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
            <div>
              <h1 className="text-2xl font-bold tracking-tight bg-gradient-to-r from-pink-600 to-purple-600 text-transparent bg-clip-text">
                Nutrition & Diet
              </h1>
              <p className="text-gray-500">
                Personalized nutrition plans and recipes to support your hormonal health and wellbeing
              </p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" className="flex items-center gap-2">
                <Coffee className="h-4 w-4" />
                <span>Food Journal</span>
              </Button>
              <Button className="bg-pink-600 hover:bg-pink-700 flex items-center gap-2">
                <Utensils className="h-4 w-4" />
                <span>Meal Planner</span>
              </Button>
            </div>
          </div>

          <div className="grid gap-6 md:grid-cols-3 mb-8">
            <Card className="bg-gradient-to-br from-pink-500/10 to-purple-500/10 border-pink-200">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-2">
                  <div className="rounded-full bg-pink-100 p-2">
                    <Apple className="h-5 w-5 text-pink-600" />
                  </div>
                  <h3 className="font-medium">Anti-Inflammatory</h3>
                </div>
                <p className="text-sm text-gray-600">
                  Foods that reduce inflammation help manage pain, hormonal symptoms, and improve overall health.
                </p>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border-pink-200">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-2">
                  <div className="rounded-full bg-purple-100 p-2">
                    <Salad className="h-5 w-5 text-purple-600" />
                  </div>
                  <h3 className="font-medium">Hormone Balance</h3>
                </div>
                <p className="text-sm text-gray-600">
                  Specific nutrients and foods that support healthy hormone production and metabolism.
                </p>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-pink-500/10 to-purple-500/10 border-pink-200">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-2">
                  <div className="rounded-full bg-pink-100 p-2">
                    <Coffee className="h-5 w-5 text-pink-600" />
                  </div>
                  <h3 className="font-medium">Blood Sugar Regulation</h3>
                </div>
                <p className="text-sm text-gray-600">
                  Balanced meals that help maintain stable blood sugar levels and reduce hormonal fluctuations.
                </p>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="plan" className="space-y-6">
            <TabsList className="bg-white/50 backdrop-blur-sm p-1 rounded-lg border">
              <TabsTrigger value="plan" className="flex items-center gap-2">
                <Utensils className="h-4 w-4" />
                <span>Nutrition Plan</span>
              </TabsTrigger>
              <TabsTrigger value="recipes" className="flex items-center gap-2">
                <Salad className="h-4 w-4" />
                <span>Recipes</span>
              </TabsTrigger>
              <TabsTrigger value="journal" className="flex items-center gap-2">
                <Coffee className="h-4 w-4" />
                <span>Food Journal</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="plan" className="space-y-6">
              <NutritionPlan />
            </TabsContent>

            <TabsContent value="recipes" className="space-y-6">
              <Card className="border-pink-200 shadow-sm">
                <CardHeader className="bg-gradient-to-r from-pink-500/5 to-purple-500/5">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                      <CardTitle>Hormone-Balancing Recipes</CardTitle>
                      <CardDescription>Delicious recipes tailored to support your hormonal health</CardDescription>
                    </div>
                    <div className="relative w-full md:w-64">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                      <Input
                        placeholder="Search recipes..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-10 border-gray-300 focus-visible:ring-pink-500"
                      />
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-6">
                  {filteredRecipes.length === 0 ? (
                    <div className="text-center py-12">
                      <p className="text-gray-500">No recipes found matching your search.</p>
                    </div>
                  ) : (
                    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                      {filteredRecipes.map((recipe) => (
                        <Card
                          key={recipe.id}
                          className="overflow-hidden border-gray-200 hover:border-pink-200 hover:shadow-md transition-all"
                        >
                          <div className="aspect-video bg-gray-100 relative">
                            <Image
                              src={recipe.image || "/placeholder.svg"}
                              alt={recipe.title}
                              fill
                              className="object-cover"
                            />
                          </div>
                          <CardContent className="p-4">
                            <div className="flex items-center justify-between mb-2">
                              <h3 className="font-medium">{recipe.title}</h3>
                              <div className="flex items-center text-sm text-gray-500">
                                <Clock className="h-3.5 w-3.5 mr-1" />
                                <span>{recipe.prepTime}</span>
                              </div>
                            </div>
                            <p className="text-sm text-gray-600 line-clamp-2 mb-3">{recipe.description}</p>
                            <div className="flex flex-wrap gap-1 mb-3">
                              {recipe.tags.map((tag) => (
                                <Badge key={tag} variant="outline" className="bg-gray-50">
                                  {tag}
                                </Badge>
                              ))}
                            </div>
                            <Button
                              variant="outline"
                              size="sm"
                              className="w-full hover:bg-pink-50 hover:text-pink-600 hover:border-pink-200"
                            >
                              View Recipe <ChevronRight className="h-3.5 w-3.5 ml-1" />
                            </Button>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}
                </CardContent>
                <CardFooter className="bg-gray-50 px-6 py-4 border-t">
                  <div className="w-full flex justify-between items-center">
                    <p className="text-sm text-gray-500">Showing {filteredRecipes.length} recipes</p>
                    <Button className="bg-pink-600 hover:bg-pink-700">Browse All Recipes</Button>
                  </div>
                </CardFooter>
              </Card>
            </TabsContent>

            <TabsContent value="journal" className="space-y-6">
              <Card className="border-pink-200 shadow-sm">
                <CardHeader className="bg-gradient-to-r from-pink-500/5 to-purple-500/5">
                  <CardTitle>Food Journal</CardTitle>
                  <CardDescription>Track your meals and identify patterns in your nutrition</CardDescription>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="flex flex-col items-center justify-center py-12 text-center">
                    <div className="rounded-full bg-gray-100 p-4 mb-4">
                      <Coffee className="h-8 w-8 text-gray-400" />
                    </div>
                    <h3 className="text-lg font-medium mb-2">No meals logged yet</h3>
                    <p className="text-gray-500 max-w-md mb-6">
                      Start tracking your meals to identify patterns, food sensitivities, and how different foods affect
                      your symptoms.
                    </p>
                    <Button className="bg-pink-600 hover:bg-pink-700">Log Your First Meal</Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>

      {/* AI Chatbot */}
      <AIChatbot />
    </div>
  )
}
