"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Progress } from "@/components/ui/progress"
import { ConditionSelector } from "@/components/condition-selector"
import { CheckCircle } from "lucide-react"

export default function Onboarding() {
  const router = useRouter()
  const [step, setStep] = useState(1)
  const [userData, setUserData] = useState({
    age: "",
    birthSex: "",
    height: "",
    weight: "",
    cycle: { regular: true, length: "28" },
    conditions: [] as string[],
    goals: [] as string[],
  })

  useEffect(() => {
    // Check if user exists and is not onboarded
    const user = localStorage.getItem("wombix_user")
    if (!user) {
      router.push("/register")
      return
    }

    try {
      const userData = JSON.parse(user)
      if (userData.isOnboarded) {
        router.push("/dashboard")
      }
    } catch (error) {
      console.error("Error parsing user data:", error)
      localStorage.removeItem("wombix_user")
      router.push("/register")
    }
  }, [router])

  const handleNext = () => {
    setStep((prev) => prev + 1)
  }

  const handleBack = () => {
    setStep((prev) => prev - 1)
  }

  const handleComplete = () => {
    try {
      // Save user data and mark as onboarded
      const userStr = localStorage.getItem("wombix_user") || "{}"
      const user = JSON.parse(userStr)

      localStorage.setItem(
        "wombix_user",
        JSON.stringify({
          ...user,
          ...userData,
          isOnboarded: true,
        }),
      )

      // Initialize empty health data
      localStorage.setItem(
        "wombix_health_data",
        JSON.stringify({
          symptoms: [],
          logs: [],
        }),
      )

      router.push("/dashboard")
    } catch (error) {
      console.error("Error completing onboarding:", error)
      // Handle error gracefully
      alert("There was an error saving your data. Please try again.")
    }
  }

  const updateUserData = (field: string, value: any) => {
    setUserData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const toggleCondition = (condition: string) => {
    setUserData((prev) => {
      const conditions = [...prev.conditions]
      if (conditions.includes(condition)) {
        return { ...prev, conditions: conditions.filter((c) => c !== condition) }
      } else {
        return { ...prev, conditions: [...conditions, condition] }
      }
    })
  }

  const toggleGoal = (goal: string) => {
    setUserData((prev) => {
      const goals = [...prev.goals]
      if (goals.includes(goal)) {
        return { ...prev, goals: goals.filter((g) => g !== goal) }
      } else {
        return { ...prev, goals: [...goals, goal] }
      }
    })
  }

  return (
    <div className="min-h-screen bg-gradient-to-r from-pink-50 to-purple-50 flex flex-col">
      <header className="border-b bg-white">
        <div className="container flex h-16 items-center px-4 md:px-6">
          <Link href="/" className="flex items-center gap-2">
            <span className="text-lg font-bold">Wombix_HerWellness</span>
          </Link>
        </div>
      </header>

      <main className="flex-1 flex items-center justify-center p-4">
        <Card className="w-full max-w-2xl">
          <CardHeader>
            <CardTitle className="text-2xl text-center">Complete Your Profile</CardTitle>
            <CardDescription className="text-center">Help us personalize your experience</CardDescription>
            <Progress value={step * 20} className="mt-2" />
          </CardHeader>
          <CardContent>
            {step === 1 && (
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Basic Information</h3>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="grid gap-2">
                    <Label htmlFor="age">Age</Label>
                    <Input
                      id="age"
                      type="number"
                      placeholder="Enter your age"
                      value={userData.age}
                      onChange={(e) => updateUserData("age", e.target.value)}
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="birthSex">Birth Sex</Label>
                    <Select value={userData.birthSex} onValueChange={(value) => updateUserData("birthSex", value)}>
                      <SelectTrigger id="birthSex">
                        <SelectValue placeholder="Select" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="female">Female</SelectItem>
                        <SelectItem value="male">Male</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="grid gap-2">
                    <Label htmlFor="height">Height (cm)</Label>
                    <Input
                      id="height"
                      type="number"
                      placeholder="Enter your height"
                      value={userData.height}
                      onChange={(e) => updateUserData("height", e.target.value)}
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="weight">Weight (kg)</Label>
                    <Input
                      id="weight"
                      type="number"
                      placeholder="Enter your weight"
                      value={userData.weight}
                      onChange={(e) => updateUserData("weight", e.target.value)}
                    />
                  </div>
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Menstrual Cycle</h3>
                <div className="grid gap-4">
                  <div className="grid gap-2">
                    <Label>Is your cycle regular?</Label>
                    <RadioGroup
                      value={userData.cycle.regular ? "yes" : "no"}
                      onValueChange={(value) =>
                        updateUserData("cycle", {
                          ...userData.cycle,
                          regular: value === "yes",
                        })
                      }
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="yes" id="cycle-yes" />
                        <Label htmlFor="cycle-yes">Yes</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="no" id="cycle-no" />
                        <Label htmlFor="cycle-no">No</Label>
                      </div>
                    </RadioGroup>
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="cycle-length">Average Cycle Length (days)</Label>
                    <Select
                      value={userData.cycle.length}
                      onValueChange={(value) =>
                        updateUserData("cycle", {
                          ...userData.cycle,
                          length: value,
                        })
                      }
                    >
                      <SelectTrigger id="cycle-length">
                        <SelectValue placeholder="Select" />
                      </SelectTrigger>
                      <SelectContent>
                        {Array.from({ length: 15 }, (_, i) => i + 21).map((num) => (
                          <SelectItem key={num} value={num.toString()}>
                            {num}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Health Conditions</h3>
                <p className="text-sm text-gray-500">
                  Select any conditions you have been diagnosed with or suspect you might have.
                </p>

                <ConditionSelector selectedConditions={userData.conditions} onToggleCondition={toggleCondition} />
              </div>
            )}

            {step === 4 && (
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Your Health Goals</h3>
                <p className="text-sm text-gray-500">
                  What are you hoping to achieve with Wombix_HerWellness? Select all that apply.
                </p>

                <div className="grid gap-3">
                  {[
                    { id: "track-symptoms", label: "Track my symptoms" },
                    { id: "understand-cycle", label: "Understand my cycle better" },
                    { id: "manage-condition", label: "Manage a specific condition" },
                    { id: "improve-nutrition", label: "Improve my nutrition" },
                  ].map((goal) => (
                    <div key={goal.id} className="flex items-center space-x-2">
                      <Checkbox
                        id={goal.id}
                        checked={userData.goals.includes(goal.label)}
                        onCheckedChange={() => toggleGoal(goal.label)}
                      />
                      <Label htmlFor={goal.id}>{goal.label}</Label>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {step === 5 && (
              <div className="space-y-4 text-center">
                <div className="mx-auto w-16 h-16 rounded-full bg-green-100 flex items-center justify-center">
                  <CheckCircle className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="text-lg font-medium">You're All Set!</h3>
                <p className="text-gray-500">
                  Thank you for completing your profile. We've personalized your Wombix_HerWellness experience based on
                  your information.
                </p>
                <p className="text-gray-500">
                  You can now start tracking your symptoms, accessing personalized insights, and exploring resources
                  tailored to your needs.
                </p>
              </div>
            )}
          </CardContent>
          <CardFooter className="flex justify-between">
            {step > 1 ? (
              <Button variant="outline" onClick={handleBack}>
                Back
              </Button>
            ) : (
              <div></div>
            )}

            {step < 5 ? (
              <Button onClick={handleNext}>Continue</Button>
            ) : (
              <Button onClick={handleComplete} className="bg-pink-600 hover:bg-pink-700">
                Complete Profile
              </Button>
            )}
          </CardFooter>
        </Card>
      </main>
    </div>
  )
}
