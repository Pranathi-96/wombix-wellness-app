"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { AIChatbot } from "@/components/ai-chatbot"
import { ArrowRight, Heart, Activity, Calendar, Brain, Sparkles, Utensils } from "lucide-react"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="container flex h-16 items-center justify-between px-4 md:px-6">
          <Link href="/" className="flex items-center gap-2">
            <span className="text-xl font-bold bg-gradient-to-r from-pink-600 to-purple-600 text-transparent bg-clip-text">
              Wombix_HerWellness
            </span>
          </Link>
          <nav className="hidden md:flex gap-6">
            <Link href="/dashboard" className="text-sm font-medium hover:text-pink-600 transition-colors">
              Dashboard
            </Link>
            <Link href="/track" className="text-sm font-medium hover:text-pink-600 transition-colors">
              Track Health
            </Link>
            <Link href="/exercise" className="text-sm font-medium hover:text-pink-600 transition-colors">
              Exercise
            </Link>
            <Link href="/nutrition" className="text-sm font-medium hover:text-pink-600 transition-colors">
              Nutrition
            </Link>
            <Link href="/resources" className="text-sm font-medium hover:text-pink-600 transition-colors">
              Resources
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Link href="/login">
              <Button variant="outline" className="hover:text-pink-600 hover:border-pink-600">
                Login
              </Button>
            </Link>
            <Link href="/register">
              <Button className="bg-pink-600 hover:bg-pink-700">Sign Up</Button>
            </Link>
          </div>
        </div>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-pink-50 to-purple-50">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
              <div className="space-y-4">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl">
                  Your Complete Women's Health Companion
                </h1>
                <p className="text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Track symptoms, get personalized health insights, nutrition plans, and access evidence-based resources
                  for your well-being journey.
                </p>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Link href="/register">
                    <Button size="lg" className="bg-pink-600 hover:bg-pink-700">
                      Get Started
                    </Button>
                  </Link>
                  <Link href="/about">
                    <Button size="lg" variant="outline" className="hover:text-pink-600 hover:border-pink-600">
                      Learn More
                    </Button>
                  </Link>
                </div>
              </div>
              <div className="mx-auto relative">
                <div className="aspect-video w-full max-w-[550px] rounded-lg bg-gradient-to-br from-pink-300 to-purple-400 flex items-center justify-center shadow-xl">
                  <div className="text-white text-center p-8">
                    <h2 className="text-2xl font-bold mb-2">Wombix_HerWellness</h2>
                    <p>Empowering women through personalized health insights</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                  How Wombix_HerWellness Helps You
                </h2>
                <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Our comprehensive platform provides everything you need for your women's health journey.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-4 mt-8">
              <div className="flex flex-col items-center space-y-2 rounded-lg border p-6 shadow-sm hover:shadow-md transition-all">
                <div className="rounded-full bg-pink-100 p-3">
                  <Activity className="h-6 w-6 text-pink-600" />
                </div>
                <h3 className="text-xl font-bold">Track Symptoms</h3>
                <p className="text-center text-gray-500">
                  Log your symptoms and health data to identify patterns and get personalized insights.
                </p>
              </div>
              <div className="flex flex-col items-center space-y-2 rounded-lg border p-6 shadow-sm hover:shadow-md transition-all">
                <div className="rounded-full bg-purple-100 p-3">
                  <Heart className="h-6 w-6 text-purple-600" />
                </div>
                <h3 className="text-xl font-bold">Personalized Nutrition</h3>
                <p className="text-center text-gray-500">
                  Get tailored nutrition plans based on your specific health needs and symptoms.
                </p>
              </div>
              <div className="flex flex-col items-center space-y-2 rounded-lg border p-6 shadow-sm hover:shadow-md transition-all">
                <div className="rounded-full bg-pink-100 p-3">
                  <Utensils className="h-6 w-6 text-pink-600" />
                </div>
                <h3 className="text-xl font-bold">Exercise Plans</h3>
                <p className="text-center text-gray-500">
                  Discover workouts designed specifically for women's health conditions like PCOS.
                </p>
              </div>
              <div className="flex flex-col items-center space-y-2 rounded-lg border p-6 shadow-sm hover:shadow-md transition-all">
                <div className="rounded-full bg-purple-100 p-3">
                  <Brain className="h-6 w-6 text-purple-600" />
                </div>
                <h3 className="text-xl font-bold">AI Health Assistant</h3>
                <p className="text-center text-gray-500">
                  Get answers to your health questions and personalized guidance from our AI assistant.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-pink-50 to-purple-50">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-8">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                  New Features You'll Love
                </h2>
                <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  We're constantly improving to provide you with the best tools for your health journey.
                </p>
              </div>
            </div>

            <div className="grid gap-6 md:grid-cols-3">
              <div className="bg-white rounded-lg shadow-lg overflow-hidden border border-pink-100">
                <div className="p-6 bg-gradient-to-r from-pink-500/10 to-purple-500/10">
                  <h3 className="text-2xl font-bold mb-2">Period Color Analyzer</h3>
                  <p className="text-gray-600 mb-4">
                    Track and analyze your menstrual blood color to better understand your cycle health and identify
                    potential issues.
                  </p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {["#e11d48", "#9f1239", "#7f1d1d", "#78350f", "#171717", "#ea580c", "#ec4899"].map((color) => (
                      <div key={color} className="w-8 h-8 rounded-full" style={{ backgroundColor: color }}></div>
                    ))}
                  </div>
                  <Link href="/track?tab=period">
                    <Button className="bg-pink-600 hover:bg-pink-700">
                      Try It Now <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-lg overflow-hidden border border-purple-100">
                <div className="p-6 bg-gradient-to-r from-purple-500/10 to-pink-500/10">
                  <h3 className="text-2xl font-bold mb-2">Exercise Recommendations</h3>
                  <p className="text-gray-600 mb-4">
                    Get personalized exercise plans designed specifically for women's health conditions like PCOS and
                    endometriosis.
                  </p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    <span className="text-xs px-2 py-1 bg-green-100 text-green-800 rounded-full">Low Impact</span>
                    <span className="text-xs px-2 py-1 bg-yellow-100 text-yellow-800 rounded-full">Strength</span>
                    <span className="text-xs px-2 py-1 bg-blue-100 text-blue-800 rounded-full">Yoga</span>
                    <span className="text-xs px-2 py-1 bg-red-100 text-red-800 rounded-full">HIIT</span>
                  </div>
                  <Link href="/exercise">
                    <Button className="bg-purple-600 hover:bg-purple-700">
                      Explore Workouts <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-lg overflow-hidden border border-pink-100">
                <div className="p-6 bg-gradient-to-r from-pink-500/10 to-purple-500/10">
                  <h3 className="text-2xl font-bold mb-2">AI Health Assistant</h3>
                  <p className="text-gray-600 mb-4">
                    Get instant answers to your health questions, personalized recommendations, and evidence-based
                    guidance.
                  </p>
                  <div className="bg-gray-100 rounded-lg p-3 mb-4">
                    <div className="flex gap-2 mb-2">
                      <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center">
                        <Brain className="h-4 w-4 text-purple-600" />
                      </div>
                      <div className="bg-white p-2 rounded-lg text-sm">
                        How can I help with your health questions today?
                      </div>
                    </div>
                    <div className="flex gap-2 justify-end">
                      <div className="bg-pink-600 p-2 rounded-lg text-sm text-white">What causes menstrual cramps?</div>
                      <div className="w-8 h-8 rounded-full bg-pink-100 flex items-center justify-center">
                        <Calendar className="h-4 w-4 text-pink-600" />
                      </div>
                    </div>
                  </div>
                  <Button
                    className="bg-pink-600 hover:bg-pink-700 w-full"
                    onClick={() =>
                      document.querySelector(".fixed.bottom-4.right-4")?.dispatchEvent(new MouseEvent("click"))
                    }
                  >
                    Chat With AI Assistant <Sparkles className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="border-t bg-white">
        <div className="container flex flex-col gap-4 py-10 md:flex-row md:gap-8 px-4 md:px-6">
          <div className="flex flex-col gap-2 md:gap-4 md:w-1/3">
            <Link href="/" className="flex items-center gap-2">
              <span className="text-lg font-bold bg-gradient-to-r from-pink-600 to-purple-600 text-transparent bg-clip-text">
                Wombix_HerWellness
              </span>
            </Link>
            <p className="text-sm text-gray-500">
              Empowering women with personalized health insights and evidence-based resources.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-4 md:grid-cols-3 md:gap-8 md:flex-1">
            <div className="space-y-2">
              <h4 className="text-sm font-medium">Product</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="/features" className="text-gray-500 hover:text-pink-600 transition-colors">
                    Features
                  </Link>
                </li>
                <li>
                  <Link href="/pricing" className="text-gray-500 hover:text-pink-600 transition-colors">
                    Pricing
                  </Link>
                </li>
                <li>
                  <Link href="/faq" className="text-gray-500 hover:text-pink-600 transition-colors">
                    FAQ
                  </Link>
                </li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="text-sm font-medium">Company</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="/about" className="text-gray-500 hover:text-pink-600 transition-colors">
                    About
                  </Link>
                </li>
                <li>
                  <Link href="/blog" className="text-gray-500 hover:text-pink-600 transition-colors">
                    Blog
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="text-gray-500 hover:text-pink-600 transition-colors">
                    Contact
                  </Link>
                </li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="text-sm font-medium">Legal</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="/privacy" className="text-gray-500 hover:text-pink-600 transition-colors">
                    Privacy
                  </Link>
                </li>
                <li>
                  <Link href="/terms" className="text-gray-500 hover:text-pink-600 transition-colors">
                    Terms
                  </Link>
                </li>
                <li>
                  <Link href="/disclaimer" className="text-gray-500 hover:text-pink-600 transition-colors">
                    Medical Disclaimer
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div className="border-t py-6 text-center text-sm">
          <p>© 2025 Wombix_HerWellness. All rights reserved.</p>
        </div>
      </footer>

      {/* AI Chatbot */}
      <AIChatbot />
    </div>
  )
}
