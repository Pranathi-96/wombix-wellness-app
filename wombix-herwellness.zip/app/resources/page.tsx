"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { MainNav } from "@/components/main-nav"
import { UserNav } from "@/components/user-nav"
import { resources } from "@/data/resources"

export default function ResourcesPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")

  useEffect(() => {
    // Check if user exists and is onboarded
    const userData = localStorage.getItem("wombix_user")
    if (!userData) {
      router.push("/login")
      return
    }

    try {
      const parsedUser = JSON.parse(userData)
      if (!parsedUser.isOnboarded) {
        router.push("/onboarding")
        return
      }

      setUser(parsedUser)
      setLoading(false)
    } catch (error) {
      console.error("Error parsing user data:", error)
      router.push("/login")
    }
  }, [router])

  const filteredResources = resources.filter(
    (resource) =>
      resource.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      resource.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      resource.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase())),
  )

  const articles = filteredResources.filter((r) => r.type === "article")
  const videos = filteredResources.filter((r) => r.type === "video")

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-pink-600 mx-auto"></div>
          <p className="mt-4 text-gray-500">Loading resources...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="border-b">
        <div className="container flex h-16 items-center px-4 md:px-6">
          <Link href="/" className="flex items-center gap-2">
            <span className="text-lg font-bold">Wombix_HerWellness</span>
          </Link>
          <MainNav className="mx-6" />
          <div className="ml-auto flex items-center space-x-4">
            <UserNav user={user} />
          </div>
        </div>
      </header>
      <main className="flex-1 p-4 md:p-6">
        <div className="container mx-auto">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-6">
            <div>
              <h1 className="text-2xl font-bold tracking-tight">Resources</h1>
              <p className="text-gray-500">Evidence-based articles and videos for your health journey</p>
            </div>
            <div className="w-full md:w-auto">
              <Input
                placeholder="Search resources..."
                className="w-full md:w-[300px]"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>

          <Tabs defaultValue="all" className="space-y-6">
            <TabsList>
              <TabsTrigger value="all">All Resources</TabsTrigger>
              <TabsTrigger value="articles">Articles</TabsTrigger>
              <TabsTrigger value="videos">Videos</TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="space-y-6">
              {filteredResources.length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-gray-500">No resources found matching your search.</p>
                </div>
              ) : (
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                  {filteredResources.map((resource) => (
                    <Link href={`/resources/${resource.id}`} key={resource.id}>
                      <Card className="h-full overflow-hidden hover:shadow-md transition-shadow">
                        <div className="p-4 bg-gray-100 flex items-center justify-center h-40">
                          <div className="text-center text-gray-500">
                            <p>{resource.type === "article" ? "Article" : "Video"}</p>
                            <p className="font-medium">{resource.title}</p>
                          </div>
                        </div>
                        <CardHeader className="pb-2">
                          <div className="flex items-center gap-2 mb-1">
                            <span
                              className={`text-xs px-2 py-1 rounded-full ${
                                resource.type === "article" ? "bg-blue-100 text-blue-800" : "bg-pink-100 text-pink-800"
                              }`}
                            >
                              {resource.type === "article" ? "Article" : "Video"}
                            </span>
                            <span className="text-xs text-gray-500">{resource.readTime || resource.duration}</span>
                          </div>
                          <CardTitle className="text-lg">{resource.title}</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-gray-500 line-clamp-2">{resource.description}</p>
                        </CardContent>
                        <CardFooter>
                          <div className="flex flex-wrap gap-1">
                            {resource.tags.slice(0, 3).map((tag) => (
                              <span key={tag} className="text-xs px-2 py-1 bg-gray-100 rounded-full">
                                {tag}
                              </span>
                            ))}
                          </div>
                        </CardFooter>
                      </Card>
                    </Link>
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="articles" className="space-y-6">
              {articles.length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-gray-500">No articles found matching your search.</p>
                </div>
              ) : (
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                  {articles.map((resource) => (
                    <Link href={`/resources/${resource.id}`} key={resource.id}>
                      <Card className="h-full overflow-hidden hover:shadow-md transition-shadow">
                        <div className="p-4 bg-gray-100 flex items-center justify-center h-40">
                          <div className="text-center text-gray-500">
                            <p>Article</p>
                            <p className="font-medium">{resource.title}</p>
                          </div>
                        </div>
                        <CardHeader className="pb-2">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-xs px-2 py-1 rounded-full bg-blue-100 text-blue-800">Article</span>
                            <span className="text-xs text-gray-500">{resource.readTime}</span>
                          </div>
                          <CardTitle className="text-lg">{resource.title}</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-gray-500 line-clamp-2">{resource.description}</p>
                        </CardContent>
                        <CardFooter>
                          <div className="flex flex-wrap gap-1">
                            {resource.tags.slice(0, 3).map((tag) => (
                              <span key={tag} className="text-xs px-2 py-1 bg-gray-100 rounded-full">
                                {tag}
                              </span>
                            ))}
                          </div>
                        </CardFooter>
                      </Card>
                    </Link>
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="videos" className="space-y-6">
              {videos.length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-gray-500">No videos found matching your search.</p>
                </div>
              ) : (
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                  {videos.map((resource) => (
                    <Link href={`/resources/${resource.id}`} key={resource.id}>
                      <Card className="h-full overflow-hidden hover:shadow-md transition-shadow">
                        <div className="p-4 bg-gray-100 flex items-center justify-center h-40">
                          <div className="text-center text-gray-500">
                            <p>Video</p>
                            <p className="font-medium">{resource.title}</p>
                          </div>
                        </div>
                        <CardHeader className="pb-2">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-xs px-2 py-1 rounded-full bg-pink-100 text-pink-800">Video</span>
                            <span className="text-xs text-gray-500">{resource.duration}</span>
                          </div>
                          <CardTitle className="text-lg">{resource.title}</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-gray-500 line-clamp-2">{resource.description}</p>
                        </CardContent>
                        <CardFooter>
                          <div className="flex flex-wrap gap-1">
                            {resource.tags.slice(0, 3).map((tag) => (
                              <span key={tag} className="text-xs px-2 py-1 bg-gray-100 rounded-full">
                                {tag}
                              </span>
                            ))}
                          </div>
                        </CardFooter>
                      </Card>
                    </Link>
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
