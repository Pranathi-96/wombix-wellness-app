"use client"

import { useState, useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { MainNav } from "@/components/main-nav"
import { UserNav } from "@/components/user-nav"
import { VideoPlayer } from "@/components/video-player"
import { resources } from "@/data/resources"

export default function ResourcePage() {
  const router = useRouter()
  const params = useParams()
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Check if user exists and is onboarded
    const userData = localStorage.getItem("wombix_user")
    if (!userData) {
      router.push("/login")
      return
    }

    try {
      const parsedUser = JSON.parse(userData)
      if (!parsedUser.isOnboarded) {
        router.push("/onboarding")
        return
      }

      setUser(parsedUser)
      setLoading(false)
    } catch (error) {
      console.error("Error parsing user data:", error)
      router.push("/login")
    }
  }, [router])

  const resourceId = params?.id as string
  const resource = resources.find((r) => r.id === resourceId)

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-pink-600 mx-auto"></div>
          <p className="mt-4 text-gray-500">Loading resource...</p>
        </div>
      </div>
    )
  }

  if (!resource) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-2">Resource Not Found</h2>
          <p className="text-gray-500 mb-4">The resource you're looking for doesn't exist or has been removed.</p>
          <Button onClick={() => router.push("/resources")}>Back to Resources</Button>
        </div>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="border-b">
        <div className="container flex h-16 items-center px-4 md:px-6">
          <Link href="/" className="flex items-center gap-2">
            <span className="text-lg font-bold">Wombix_HerWellness</span>
          </Link>
          <MainNav className="mx-6" />
          <div className="ml-auto flex items-center space-x-4">
            <UserNav user={user} />
          </div>
        </div>
      </header>
      <main className="flex-1 p-4 md:p-6">
        <div className="container mx-auto max-w-4xl">
          <div className="mb-6">
            <Button variant="outline" size="sm" onClick={() => router.push("/resources")}>
              ← Back to Resources
            </Button>
          </div>

          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <span
                className={`text-xs px-2 py-1 rounded-full ${
                  resource.type === "article" ? "bg-blue-100 text-blue-800" : "bg-pink-100 text-pink-800"
                }`}
              >
                {resource.type === "article" ? "Article" : "Video"}
              </span>
              <span className="text-xs text-gray-500">{resource.readTime || resource.duration}</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-bold tracking-tight mb-2">{resource.title}</h1>
            <p className="text-gray-500">{resource.description}</p>
            <div className="flex flex-wrap gap-1 mt-2">
              {resource.tags.map((tag) => (
                <span key={tag} className="text-xs px-2 py-1 bg-gray-100 rounded-full">
                  {tag}
                </span>
              ))}
            </div>
          </div>

          {resource.type === "video" ? (
            <div className="mb-8">
              <VideoPlayer videoUrl={resource.videoUrl} title={resource.title} />

              <div className="mt-6">
                <h2 className="text-xl font-bold mb-4">Transcript</h2>
                <Card className="p-4 bg-gray-50">
                  <div className="prose max-w-none">
                    {resource.transcript?.split("\n\n").map((paragraph, i) => (
                      <p key={i} className="mb-4">
                        {paragraph}
                      </p>
                    ))}
                  </div>
                </Card>
              </div>
            </div>
          ) : (
            <div className="mb-8">
              <div className="bg-gray-100 p-6 rounded-lg mb-6 flex items-center justify-center">
                <div className="text-center text-gray-500">
                  <p className="text-lg font-medium">{resource.title}</p>
                  <p>Article Preview</p>
                </div>
              </div>

              <div className="prose max-w-none">
                {resource.content?.split("\n\n").map((paragraph, i) => (
                  <p key={i} className="mb-4">
                    {paragraph}
                  </p>
                ))}
              </div>
            </div>
          )}

          <div className="border-t pt-6">
            <h2 className="text-xl font-bold mb-4">Related Resources</h2>
            <div className="grid gap-6 md:grid-cols-3">
              {resources
                .filter((r) => r.id !== resource.id && r.tags.some((tag) => resource.tags.includes(tag)))
                .slice(0, 3)
                .map((relatedResource) => (
                  <Link href={`/resources/${relatedResource.id}`} key={relatedResource.id}>
                    <Card className="h-full overflow-hidden hover:shadow-md transition-shadow">
                      <div className="p-4 bg-gray-100 flex items-center justify-center h-40">
                        <div className="text-center text-gray-500">
                          <p>{relatedResource.type === "article" ? "Article" : "Video"}</p>
                          <p className="font-medium">{relatedResource.title}</p>
                        </div>
                      </div>
                      <div className="p-4">
                        <div className="flex items-center gap-2 mb-1">
                          <span
                            className={`text-xs px-2 py-1 rounded-full ${
                              relatedResource.type === "article"
                                ? "bg-blue-100 text-blue-800"
                                : "bg-pink-100 text-pink-800"
                            }`}
                          >
                            {relatedResource.type === "article" ? "Article" : "Video"}
                          </span>
                          <span className="text-xs text-gray-500">
                            {relatedResource.readTime || relatedResource.duration}
                          </span>
                        </div>
                        <h3 className="font-medium line-clamp-2">{relatedResource.title}</h3>
                      </div>
                    </Card>
                  </Link>
                ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
