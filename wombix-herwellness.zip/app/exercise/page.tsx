"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MainNav } from "@/components/main-nav"
import { UserNav } from "@/components/user-nav"
import { ExerciseRecommendations } from "@/components/exercise-recommendations"
import { AIChatbot } from "@/components/ai-chatbot"
import { Dumbbell, Heart, Calendar, Activity } from "lucide-react"

export default function ExercisePage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Check if user exists and is onboarded
    const userData = localStorage.getItem("wombix_user")
    if (!userData) {
      router.push("/login")
      return
    }

    try {
      const parsedUser = JSON.parse(userData)
      if (!parsedUser.isOnboarded) {
        router.push("/onboarding")
        return
      }

      setUser(parsedUser)
      setLoading(false)
    } catch (error) {
      console.error("Error parsing user data:", error)
      router.push("/login")
    }
  }, [router])

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-pink-600 mx-auto"></div>
          <p className="mt-4 text-gray-500">Loading exercise recommendations...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-br from-pink-50 to-purple-50">
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="container flex h-16 items-center px-4 md:px-6">
          <Link href="/" className="flex items-center gap-2">
            <span className="text-lg font-bold bg-gradient-to-r from-pink-600 to-purple-600 text-transparent bg-clip-text">
              Wombix_HerWellness
            </span>
          </Link>
          <MainNav className="mx-6" />
          <div className="ml-auto flex items-center space-x-4">
            <UserNav user={user} />
          </div>
        </div>
      </header>
      <main className="flex-1 p-4 md:p-6">
        <div className="container mx-auto max-w-6xl">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
            <div>
              <h1 className="text-2xl font-bold tracking-tight bg-gradient-to-r from-pink-600 to-purple-600 text-transparent bg-clip-text">
                Exercise & Movement
              </h1>
              <p className="text-gray-500">
                Personalized exercise recommendations to support your hormonal health and wellbeing
              </p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" className="flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                <span>My Exercise Plan</span>
              </Button>
              <Button className="bg-pink-600 hover:bg-pink-700 flex items-center gap-2">
                <Activity className="h-4 w-4" />
                <span>Log Activity</span>
              </Button>
            </div>
          </div>

          <div className="grid gap-6 md:grid-cols-3 mb-8">
            <Card className="bg-gradient-to-br from-pink-500/10 to-purple-500/10 border-pink-200">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-2">
                  <div className="rounded-full bg-pink-100 p-2">
                    <Heart className="h-5 w-5 text-pink-600" />
                  </div>
                  <h3 className="font-medium">Hormonal Health</h3>
                </div>
                <p className="text-sm text-gray-600">
                  Regular exercise helps regulate hormones, reduce stress, and improve insulin sensitivity.
                </p>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border-pink-200">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-2">
                  <div className="rounded-full bg-purple-100 p-2">
                    <Dumbbell className="h-5 w-5 text-purple-600" />
                  </div>
                  <h3 className="font-medium">Strength & Energy</h3>
                </div>
                <p className="text-sm text-gray-600">
                  Building muscle improves metabolism, energy levels, and helps manage weight effectively.
                </p>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-pink-500/10 to-purple-500/10 border-pink-200">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-2">
                  <div className="rounded-full bg-pink-100 p-2">
                    <Activity className="h-5 w-5 text-pink-600" />
                  </div>
                  <h3 className="font-medium">Mood & Stress</h3>
                </div>
                <p className="text-sm text-gray-600">
                  Movement releases endorphins that improve mood, reduce anxiety, and help manage stress.
                </p>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="recommendations" className="space-y-6">
            <TabsList className="bg-white/50 backdrop-blur-sm p-1 rounded-lg border">
              <TabsTrigger value="recommendations" className="flex items-center gap-2">
                <Heart className="h-4 w-4" />
                <span>Recommendations</span>
              </TabsTrigger>
              <TabsTrigger value="videos" className="flex items-center gap-2">
                <Activity className="h-4 w-4" />
                <span>Exercise Videos</span>
              </TabsTrigger>
              <TabsTrigger value="progress" className="flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                <span>My Progress</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="recommendations" className="space-y-6">
              <ExerciseRecommendations />
            </TabsContent>

            <TabsContent value="videos" className="space-y-6">
              <Card className="border-pink-200 shadow-sm">
                <CardHeader className="bg-gradient-to-r from-pink-500/5 to-purple-500/5">
                  <CardTitle>Exercise Videos</CardTitle>
                  <CardDescription>Watch guided workout videos tailored to your health needs</CardDescription>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                    <Card className="overflow-hidden border-gray-200 hover:border-pink-200 hover:shadow-md transition-all">
                      <div className="aspect-video bg-gray-100 relative">
                        <video
                          src="https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
                          poster="/placeholder.svg?height=200&width=300"
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 flex items-center justify-center">
                          <div className="rounded-full bg-pink-600/90 p-3 cursor-pointer hover:bg-pink-700/90 transition-colors">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="24"
                              height="24"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              className="text-white"
                            >
                              <polygon points="5 3 19 12 5 21 5 3" />
                            </svg>
                          </div>
                        </div>
                      </div>
                      <CardContent className="p-4">
                        <h3 className="font-medium mb-1">Yoga for PCOS</h3>
                        <p className="text-sm text-gray-500 mb-2">20 min • Low Impact</p>
                        <div className="flex flex-wrap gap-1">
                          <span className="text-xs px-2 py-0.5 bg-pink-100 text-pink-800 rounded-full">PCOS</span>
                          <span className="text-xs px-2 py-0.5 bg-purple-100 text-purple-800 rounded-full">Yoga</span>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="overflow-hidden border-gray-200 hover:border-pink-200 hover:shadow-md transition-all">
                      <div className="aspect-video bg-gray-100 relative">
                        <video
                          src="https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"
                          poster="/placeholder.svg?height=200&width=300"
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 flex items-center justify-center">
                          <div className="rounded-full bg-pink-600/90 p-3 cursor-pointer hover:bg-pink-700/90 transition-colors">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="24"
                              height="24"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              className="text-white"
                            >
                              <polygon points="5 3 19 12 5 21 5 3" />
                            </svg>
                          </div>
                        </div>
                      </div>
                      <CardContent className="p-4">
                        <h3 className="font-medium mb-1">HIIT for Hormonal Balance</h3>
                        <p className="text-sm text-gray-500 mb-2">15 min • High Intensity</p>
                        <div className="flex flex-wrap gap-1">
                          <span className="text-xs px-2 py-0.5 bg-green-100 text-green-800 rounded-full">Energy</span>
                          <span className="text-xs px-2 py-0.5 bg-blue-100 text-blue-800 rounded-full">Metabolism</span>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="overflow-hidden border-gray-200 hover:border-pink-200 hover:shadow-md transition-all">
                      <div className="aspect-video bg-gray-100 relative">
                        <video
                          src="https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4"
                          poster="/placeholder.svg?height=200&width=300"
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 flex items-center justify-center">
                          <div className="rounded-full bg-pink-600/90 p-3 cursor-pointer hover:bg-pink-700/90 transition-colors">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="24"
                              height="24"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              className="text-white"
                            >
                              <polygon points="5 3 19 12 5 21 5 3" />
                            </svg>
                          </div>
                        </div>
                      </div>
                      <CardContent className="p-4">
                        <h3 className="font-medium mb-1">Strength Training Basics</h3>
                        <p className="text-sm text-gray-500 mb-2">25 min • Medium Intensity</p>
                        <div className="flex flex-wrap gap-1">
                          <span className="text-xs px-2 py-0.5 bg-yellow-100 text-yellow-800 rounded-full">
                            Strength
                          </span>
                          <span className="text-xs px-2 py-0.5 bg-red-100 text-red-800 rounded-full">Toning</span>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="progress" className="space-y-6">
              <Card className="border-pink-200 shadow-sm">
                <CardHeader className="bg-gradient-to-r from-pink-500/5 to-purple-500/5">
                  <CardTitle>My Exercise Progress</CardTitle>
                  <CardDescription>Track your activity and see your progress over time</CardDescription>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="flex flex-col items-center justify-center py-12 text-center">
                    <div className="rounded-full bg-gray-100 p-4 mb-4">
                      <Activity className="h-8 w-8 text-gray-400" />
                    </div>
                    <h3 className="text-lg font-medium mb-2">No activity logged yet</h3>
                    <p className="text-gray-500 max-w-md mb-6">
                      Start tracking your exercise to see your progress, patterns, and improvements over time.
                    </p>
                    <Button className="bg-pink-600 hover:bg-pink-700">Log Your First Activity</Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>

      {/* AI Chatbot */}
      <AIChatbot />
    </div>
  )
}
