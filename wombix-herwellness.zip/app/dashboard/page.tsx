"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MainNav } from "@/components/main-nav"
import { UserNav } from "@/components/user-nav"
import { HealthSummary } from "@/components/health-summary"
import { RecentLogs } from "@/components/recent-logs"
import { RecommendedResources } from "@/components/recommended-resources"
import { NutritionPlan } from "@/components/nutrition-plan"
import { AIChatbot } from "@/components/ai-chatbot"
import { Calendar, LineChart, Droplets, Activity, BarChart3, Dumbbell, Clock } from "lucide-react"

export default function Dashboard() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Check if user exists and is onboarded
    const userData = localStorage.getItem("wombix_user")
    if (!userData) {
      router.push("/login")
      return
    }

    try {
      const parsedUser = JSON.parse(userData)
      if (!parsedUser.isOnboarded) {
        router.push("/onboarding")
        return
      }

      setUser(parsedUser)
      setLoading(false)
    } catch (error) {
      console.error("Error parsing user data:", error)
      router.push("/login")
    }
  }, [router])

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-pink-600 mx-auto"></div>
          <p className="mt-4 text-gray-500">Loading your dashboard...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-br from-pink-50 to-purple-50">
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="container flex h-16 items-center px-4 md:px-6">
          <Link href="/" className="flex items-center gap-2">
            <span className="text-lg font-bold bg-gradient-to-r from-pink-600 to-purple-600 text-transparent bg-clip-text">
              Wombix_HerWellness
            </span>
          </Link>
          <MainNav className="mx-6" />
          <div className="ml-auto flex items-center space-x-4">
            <UserNav user={user} />
          </div>
        </div>
      </header>
      <main className="flex-1 p-4 md:p-6">
        <div className="container mx-auto">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl font-bold tracking-tight bg-gradient-to-r from-pink-600 to-purple-600 text-transparent bg-clip-text">
              Welcome back, {user.name}
            </h1>
            <Link href="/track">
              <Button className="bg-pink-600 hover:bg-pink-700">Track Today</Button>
            </Link>
          </div>

          <Tabs defaultValue="overview" className="space-y-6">
            <TabsList className="bg-white/50 backdrop-blur-sm p-1 rounded-lg border">
              <TabsTrigger value="overview" className="flex items-center gap-2">
                <Activity className="h-4 w-4" />
                <span>Overview</span>
              </TabsTrigger>
              <TabsTrigger value="insights" className="flex items-center gap-2">
                <BarChart3 className="h-4 w-4" />
                <span>Health Insights</span>
              </TabsTrigger>
              <TabsTrigger value="exercise" className="flex items-center gap-2">
                <Dumbbell className="h-4 w-4" />
                <span>Exercise</span>
              </TabsTrigger>
              <TabsTrigger value="nutrition" className="flex items-center gap-2">
                <LineChart className="h-4 w-4" />
                <span>Nutrition</span>
              </TabsTrigger>
              <TabsTrigger value="resources" className="flex items-center gap-2">
                <Droplets className="h-4 w-4" />
                <span>Resources</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                <Card className="border-pink-200 shadow-md overflow-hidden">
                  <CardHeader className="pb-2 bg-gradient-to-r from-pink-500/10 to-purple-500/10">
                    <CardTitle>Cycle Day</CardTitle>
                    <CardDescription>Your current cycle status</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-center py-4">
                      <div className="text-center">
                        <div className="text-5xl font-bold text-pink-600">14</div>
                        <p className="text-sm text-gray-500 mt-1">of 28 days</p>
                        <p className="mt-2 font-medium">Ovulation Phase</p>
                        <div className="w-full bg-gray-200 rounded-full h-2.5 mt-3">
                          <div className="bg-pink-600 h-2.5 rounded-full" style={{ width: "50%" }}></div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-pink-200 shadow-md overflow-hidden">
                  <CardHeader className="pb-2 bg-gradient-to-r from-pink-500/10 to-purple-500/10">
                    <CardTitle>Symptom Trends</CardTitle>
                    <CardDescription>Last 30 days</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[150px] flex items-center justify-center">
                      <div className="w-full h-full flex items-end justify-around gap-1 pt-4">
                        {[30, 45, 25, 60, 40, 80, 35, 55, 45, 70, 50, 40].map((height, i) => (
                          <div key={i} className="flex-1 flex flex-col items-center">
                            <div
                              className="w-full bg-pink-600 rounded-t-sm"
                              style={{ height: `${height}%`, opacity: 0.6 + (i % 3) * 0.2 }}
                            ></div>
                            <div className="text-xs text-gray-500 mt-1">{i + 1}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-pink-200 shadow-md overflow-hidden">
                  <CardHeader className="pb-2 bg-gradient-to-r from-pink-500/10 to-purple-500/10">
                    <CardTitle>Quick Actions</CardTitle>
                    <CardDescription>Common tasks</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-2">
                      <Link href="/track">
                        <Button
                          variant="outline"
                          className="w-full justify-start hover:bg-pink-50 hover:text-pink-700 hover:border-pink-200"
                        >
                          <LineChart className="h-4 w-4 mr-2" />
                          Log Symptoms
                        </Button>
                      </Link>
                      <Link href="/track?tab=period">
                        <Button
                          variant="outline"
                          className="w-full justify-start hover:bg-pink-50 hover:text-pink-700 hover:border-pink-200"
                        >
                          <Droplets className="h-4 w-4 mr-2" />
                          Track Period
                        </Button>
                      </Link>
                      <Link href="/exercise">
                        <Button
                          variant="outline"
                          className="w-full justify-start hover:bg-pink-50 hover:text-pink-700 hover:border-pink-200"
                        >
                          <Dumbbell className="h-4 w-4 mr-2" />
                          Exercise
                        </Button>
                      </Link>
                      <Link href="/resources">
                        <Button
                          variant="outline"
                          className="w-full justify-start hover:bg-pink-50 hover:text-pink-700 hover:border-pink-200"
                        >
                          <Calendar className="h-4 w-4 mr-2" />
                          Resources
                        </Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <HealthSummary />
                <RecentLogs />
              </div>

              <RecommendedResources />
            </TabsContent>

            <TabsContent value="insights" className="space-y-6">
              <HealthSummary detailed />
            </TabsContent>

            <TabsContent value="exercise" className="space-y-6">
              <Card className="border-pink-200 shadow-md overflow-hidden">
                <CardHeader className="bg-gradient-to-r from-pink-500/10 to-purple-500/10">
                  <div className="flex justify-between items-center">
                    <div>
                      <CardTitle>Exercise Recommendations</CardTitle>
                      <CardDescription>Personalized workouts based on your health profile</CardDescription>
                    </div>
                    <Link href="/exercise">
                      <Button size="sm" className="bg-pink-600 hover:bg-pink-700">
                        View All
                      </Button>
                    </Link>
                  </div>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="grid gap-4 md:grid-cols-3">
                    <Card className="overflow-hidden border-gray-200 hover:border-pink-200 hover:shadow-md transition-all">
                      <div className="bg-gradient-to-r from-pink-500/5 to-purple-500/5 p-4 border-b">
                        <div className="flex justify-between items-start mb-2">
                          <h3 className="font-medium">Yoga for PCOS</h3>
                          <span className="text-xs px-2 py-0.5 bg-green-100 text-green-800 rounded-full">Low</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-gray-500">
                          <Clock className="h-3.5 w-3.5" />
                          <span>20 min</span>
                        </div>
                      </div>
                      <CardContent className="p-4">
                        <p className="text-sm text-gray-600 line-clamp-2 mb-3">
                          A gentle sequence of yoga poses designed to reduce stress and balance hormones.
                        </p>
                        <Link href="/exercise">
                          <Button size="sm" variant="outline" className="w-full">
                            View Details
                          </Button>
                        </Link>
                      </CardContent>
                    </Card>

                    <Card className="overflow-hidden border-gray-200 hover:border-pink-200 hover:shadow-md transition-all">
                      <div className="bg-gradient-to-r from-pink-500/5 to-purple-500/5 p-4 border-b">
                        <div className="flex justify-between items-start mb-2">
                          <h3 className="font-medium">PCOS-Friendly HIIT</h3>
                          <span className="text-xs px-2 py-0.5 bg-red-100 text-red-800 rounded-full">High</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-gray-500">
                          <Clock className="h-3.5 w-3.5" />
                          <span>20 min</span>
                        </div>
                      </div>
                      <CardContent className="p-4">
                        <p className="text-sm text-gray-600 line-clamp-2 mb-3">
                          Modified high-intensity interval training designed specifically for women with PCOS.
                        </p>
                        <Link href="/exercise">
                          <Button size="sm" variant="outline" className="w-full">
                            View Details
                          </Button>
                        </Link>
                      </CardContent>
                    </Card>

                    <Card className="overflow-hidden border-gray-200 hover:border-pink-200 hover:shadow-md transition-all">
                      <div className="bg-gradient-to-r from-pink-500/5 to-purple-500/5 p-4 border-b">
                        <div className="flex justify-between items-start mb-2">
                          <h3 className="font-medium">Strength Training</h3>
                          <span className="text-xs px-2 py-0.5 bg-yellow-100 text-yellow-800 rounded-full">Medium</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-gray-500">
                          <Clock className="h-3.5 w-3.5" />
                          <span>30 min</span>
                        </div>
                      </div>
                      <CardContent className="p-4">
                        <p className="text-sm text-gray-600 line-clamp-2 mb-3">
                          Resistance training exercises that help build lean muscle mass and improve metabolic health.
                        </p>
                        <Link href="/exercise">
                          <Button size="sm" variant="outline" className="w-full">
                            View Details
                          </Button>
                        </Link>
                      </CardContent>
                    </Card>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="nutrition" className="space-y-6">
              <NutritionPlan />
            </TabsContent>

            <TabsContent value="resources" className="space-y-6">
              <RecommendedResources showAll />
            </TabsContent>
          </Tabs>
        </div>
      </main>

      {/* AI Chatbot */}
      <AIChatbot />
    </div>
  )
}
