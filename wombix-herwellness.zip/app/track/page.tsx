"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MainNav } from "@/components/main-nav"
import { UserNav } from "@/components/user-nav"
import { SymptomTracker } from "@/components/symptom-tracker"
import { PeriodColorAnalyzer } from "@/components/period-color-analyzer"
import { AIChatbot } from "@/components/ai-chatbot"
import { Calendar, LineChart, Droplets } from "lucide-react"

export default function TrackPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [notes, setNotes] = useState("")
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([])
  const [activeTab, setActiveTab] = useState("symptoms")

  useEffect(() => {
    // Check if user exists and is onboarded
    const userData = localStorage.getItem("wombix_user")
    if (!userData) {
      router.push("/login")
      return
    }

    try {
      const parsedUser = JSON.parse(userData)
      if (!parsedUser.isOnboarded) {
        router.push("/onboarding")
        return
      }

      setUser(parsedUser)
      setLoading(false)
    } catch (error) {
      console.error("Error parsing user data:", error)
      router.push("/login")
    }
  }, [router])

  const handleSaveLog = () => {
    try {
      // Get existing health data
      const healthDataStr = localStorage.getItem("wombix_health_data")
      const healthData = healthDataStr ? JSON.parse(healthDataStr) : { symptoms: [], logs: [] }

      // Add new log
      const newLog = {
        date: new Date().toISOString(),
        symptoms: selectedSymptoms,
        notes: notes,
      }

      healthData.logs.unshift(newLog)

      // Update symptoms frequency
      selectedSymptoms.forEach((symptom) => {
        const existingSymptom = healthData.symptoms.find((s: any) => s.name === symptom)
        if (existingSymptom) {
          existingSymptom.count = (existingSymptom.count || 0) + 1
        } else {
          healthData.symptoms.push({ name: symptom, count: 1 })
        }
      })

      // Save updated health data
      localStorage.setItem("wombix_health_data", JSON.stringify(healthData))

      // Redirect to dashboard
      router.push("/dashboard")
    } catch (error) {
      console.error("Error saving health log:", error)
      alert("There was an error saving your data. Please try again.")
    }
  }

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-pink-600 mx-auto"></div>
          <p className="mt-4 text-gray-500">Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-br from-pink-50 to-purple-50">
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="container flex h-16 items-center px-4 md:px-6">
          <Link href="/" className="flex items-center gap-2">
            <span className="text-lg font-bold bg-gradient-to-r from-pink-600 to-purple-600 text-transparent bg-clip-text">
              Wombix_HerWellness
            </span>
          </Link>
          <MainNav className="mx-6" />
          <div className="ml-auto flex items-center space-x-4">
            <UserNav user={user} />
          </div>
        </div>
      </header>
      <main className="flex-1 p-4 md:p-6">
        <div className="container mx-auto max-w-4xl">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-2xl font-bold tracking-tight bg-gradient-to-r from-pink-600 to-purple-600 text-transparent bg-clip-text">
                Track Your Health
              </h1>
              <p className="text-gray-500">
                Record your symptoms, period details, and notes to get personalized insights
              </p>
            </div>
            <div className="text-sm text-gray-500 bg-white px-3 py-2 rounded-md shadow-sm border">
              {new Date().toLocaleDateString("en-US", {
                weekday: "long",
                year: "numeric",
                month: "long",
                day: "numeric",
              })}
            </div>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid grid-cols-3 mb-4">
              <TabsTrigger value="symptoms" className="flex items-center gap-2">
                <LineChart className="h-4 w-4" />
                <span>Symptoms</span>
              </TabsTrigger>
              <TabsTrigger value="period" className="flex items-center gap-2">
                <Droplets className="h-4 w-4" />
                <span>Period Color</span>
              </TabsTrigger>
              <TabsTrigger value="calendar" className="flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                <span>Calendar</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="symptoms" className="space-y-6">
              <Card className="mb-6 border-pink-200 shadow-md">
                <CardHeader className="bg-gradient-to-r from-pink-500/10 to-purple-500/10">
                  <CardTitle>How are you feeling today?</CardTitle>
                  <CardDescription>
                    Track your symptoms to get personalized insights and recommendations.
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-6">
                  <SymptomTracker
                    selectedSymptoms={selectedSymptoms}
                    onSelectSymptom={(symptom) => {
                      if (selectedSymptoms.includes(symptom)) {
                        setSelectedSymptoms(selectedSymptoms.filter((s) => s !== symptom))
                      } else {
                        setSelectedSymptoms([...selectedSymptoms, symptom])
                      }
                    }}
                  />
                </CardContent>
              </Card>

              <Card className="mb-6 border-pink-200 shadow-md">
                <CardHeader className="bg-gradient-to-r from-pink-500/10 to-purple-500/10">
                  <CardTitle>Notes</CardTitle>
                  <CardDescription>Add any additional details about how you're feeling today.</CardDescription>
                </CardHeader>
                <CardContent>
                  <Textarea
                    placeholder="Enter any notes about your symptoms, mood, or other observations..."
                    className="min-h-[120px]"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                  />
                </CardContent>
              </Card>

              <div className="flex justify-end gap-4">
                <Button variant="outline" onClick={() => router.push("/dashboard")}>
                  Cancel
                </Button>
                <Button onClick={handleSaveLog} className="bg-pink-600 hover:bg-pink-700">
                  Save Log
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="period" className="space-y-6">
              <PeriodColorAnalyzer />
            </TabsContent>

            <TabsContent value="calendar" className="space-y-6">
              <Card className="border-pink-200 shadow-md">
                <CardHeader className="bg-gradient-to-r from-pink-500/10 to-purple-500/10">
                  <CardTitle>Health Calendar</CardTitle>
                  <CardDescription>View and track your health patterns over time</CardDescription>
                </CardHeader>
                <CardContent className="pt-6">
                  <div className="bg-white p-6 rounded-lg border text-center">
                    <div className="grid grid-cols-7 gap-1 mb-2">
                      {["S", "M", "T", "W", "T", "F", "S"].map((day, i) => (
                        <div key={i} className="text-sm font-medium text-gray-500">
                          {day}
                        </div>
                      ))}
                    </div>
                    <div className="grid grid-cols-7 gap-1">
                      {Array.from({ length: 35 }, (_, i) => {
                        const day = i - 3 + 1 // Adjust for month start on Thursday
                        const isToday = day === 15
                        const isPeriod = day >= 5 && day <= 10
                        const isFertile = day >= 14 && day <= 17
                        const isOvulation = day === 16

                        return (
                          <div
                            key={i}
                            className={`aspect-square flex items-center justify-center rounded-full text-sm relative ${
                              day <= 0 || day > 31
                                ? "text-gray-300"
                                : isToday
                                  ? "bg-pink-600 text-white font-bold"
                                  : "hover:bg-gray-100 cursor-pointer"
                            }`}
                          >
                            {day > 0 && day <= 31 ? day : ""}
                            {isPeriod && day > 0 && day <= 31 && (
                              <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-red-500"></div>
                            )}
                            {isFertile && day > 0 && day <= 31 && !isPeriod && (
                              <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-green-500"></div>
                            )}
                            {isOvulation && (
                              <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-purple-500"></div>
                            )}
                          </div>
                        )
                      })}
                    </div>
                    <div className="flex justify-center gap-6 mt-6">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-red-500"></div>
                        <span className="text-sm text-gray-600">Period</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-green-500"></div>
                        <span className="text-sm text-gray-600">Fertile Window</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-purple-500"></div>
                        <span className="text-sm text-gray-600">Ovulation</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>

      {/* AI Chatbot */}
      <AIChatbot />
    </div>
  )
}
