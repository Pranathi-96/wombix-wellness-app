// Updated resources data with working video URLs and PCOS/PCOD specific content
export const resources = [
  {
    id: "pcos-nutrition",
    type: "article",
    title: "Nutrition Strategies for PCOS Management",
    description: "Evidence-based dietary approaches to manage PCOS symptoms and improve hormonal balance.",
    readTime: "8 min read",
    tags: ["PCOS", "Nutrition", "Hormonal Health", "Insulin Resistance"],
    content: `Polycystic Ovary Syndrome (PCOS) affects approximately 1 in 10 women of reproductive age, making it one of the most common hormonal disorders. While there is no cure for PCOS, nutrition plays a crucial role in managing symptoms and improving overall health outcomes.

The connection between PCOS and insulin resistance is well-established, with up to 70% of women with PCOS experiencing some degree of insulin resistance. This metabolic dysfunction can drive many PCOS symptoms, including irregular periods, excess androgen production, and weight management difficulties.

A strategic nutritional approach can help address insulin resistance and reduce symptom severity. Here are evidence-based dietary strategies for PCOS management:

1. Focus on Low Glycemic Index Foods
Foods with a low glycemic index (GI) cause a slower, more gradual rise in blood sugar levels. Research shows that low-GI diets can improve insulin sensitivity, reduce testosterone levels, and regulate menstrual cycles in women with PCOS.

Low-GI foods to emphasize include:
- Whole grains (quinoa, brown rice, oats)
- Legumes (lentils, chickpeas, beans)
- Most fruits and non-starchy vegetables
- Nuts and seeds`,
  },
  {
    id: "endometriosis-pain",
    type: "video",
    title: "Managing Endometriosis Pain: Expert Techniques",
    description: "Learn effective pain management strategies for endometriosis from women's health specialists.",
    duration: "12:45",
    videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
    tags: ["Endometriosis", "Pain Management", "Women's Health", "Chronic Pain"],
    transcript: `Hello and welcome to this video on managing endometriosis pain. I'm Dr. Sarah Johnson, a gynecologist specializing in endometriosis care, and today I'll be sharing evidence-based strategies to help you manage endometriosis pain more effectively.

Endometriosis affects approximately 1 in 10 women of reproductive age worldwide, and pain is one of its most debilitating symptoms. This pain can manifest as severe menstrual cramps, pain during intercourse, chronic pelvic pain, and even pain during urination or bowel movements.

Before we dive into management strategies, it's important to understand why endometriosis causes pain. Endometriosis occurs when tissue similar to the lining of the uterus grows outside the uterus. This tissue responds to hormonal changes during your menstrual cycle, causing inflammation, scarring, and pain.`,
  },
  {
    id: "hormonal-balance",
    type: "article",
    title: "Natural Ways to Support Hormonal Balance",
    description: "Lifestyle and dietary approaches to promote healthy hormone levels throughout your cycle.",
    readTime: "6 min read",
    tags: ["Hormonal Health", "Natural Remedies", "Nutrition", "Lifestyle"],
    content: `Hormones are powerful chemical messengers that regulate everything from reproduction and metabolism to mood and sleep. When hormones are in balance, we feel energetic, emotionally stable, and our bodily functions run smoothly. However, factors like stress, poor nutrition, environmental toxins, and certain health conditions can disrupt this delicate balance.

For women especially, hormonal fluctuations throughout the menstrual cycle are normal, but excessive imbalances can lead to symptoms like irregular periods, mood swings, fatigue, weight changes, and sleep disturbances. While medical intervention is sometimes necessary, there are many natural approaches that can support hormonal balance.

Here are evidence-based strategies to help your body maintain healthy hormone levels:

1. Prioritize Nutrient-Dense Foods
What you eat has a profound impact on hormone production and metabolism. Focus on:

- Healthy fats: Avocados, olive oil, nuts, and seeds provide the building blocks for hormone production.
- Quality protein: Organic eggs, wild-caught fish, and legumes support enzyme function and hormone transport.
- Fiber-rich foods: Cruciferous vegetables like broccoli and cauliflower help the body eliminate excess estrogen.
- Antioxidant-rich foods: Berries, leafy greens, and herbs combat inflammation that can disrupt hormonal balance.`,
  },
  {
    id: "fertility-myths",
    type: "video",
    title: "Fertility Myths Debunked by Reproductive Specialists",
    description: "Leading fertility experts separate fact from fiction about conception and reproductive health.",
    duration: "15:20",
    videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
    tags: ["Fertility", "Reproductive Health", "Trying to Conceive", "Women's Health"],
    transcript: `Welcome to "Fertility Myths Debunked." I'm Dr. Rebecca Chen, a reproductive endocrinologist, and today I'm joined by my colleague Dr. Michael Torres, a fertility specialist with over 15 years of experience. Together, we'll address some of the most common misconceptions about fertility and reproductive health.

Dr. Torres: Thanks for having me, Dr. Chen. In our practices, we both encounter patients who have received a lot of misinformation about fertility, often from well-meaning friends, family, or even the internet. Today, we want to set the record straight on some of these myths.

Dr. Chen: Absolutely. Let's start with one of the most persistent myths: that women can easily get pregnant at any age until menopause.`,
  },
  {
    id: "thyroid-health",
    type: "video",
    title: "Understanding Thyroid Health for Women",
    description: "How thyroid function affects women's health and what to do if you suspect an imbalance.",
    duration: "18:35",
    videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
    tags: ["Thyroid Health", "Hormonal Health", "Energy", "Metabolism"],
    transcript: `Hello and welcome to our comprehensive guide on thyroid health for women. I'm Dr. Lisa Martinez, an endocrinologist specializing in women's hormonal health, and today we're going to explore the critical role your thyroid plays in your overall wellbeing.

The thyroid gland might be small—it's only about two inches long and shaped like a butterfly—but its impact on your body is enormous. This remarkable gland produces hormones that regulate metabolism, energy production, body temperature, and even influences your heart rate, menstrual cycles, and mood.

Women are five to eight times more likely than men to develop thyroid disorders, making this a particularly important topic for women's health. Let's dive into understanding this vital gland and how to keep it functioning optimally.`,
  },
  {
    id: "period-color-guide",
    type: "article",
    title: "Understanding Period Blood Colors: What They Mean for Your Health",
    description:
      "A comprehensive guide to interpreting different menstrual blood colors and what they indicate about your health.",
    readTime: "7 min read",
    tags: ["Menstruation", "Period Health", "Women's Health", "Reproductive Health"],
    content: `The color of your menstrual blood can provide valuable insights into your reproductive health. While variations in color are often normal and reflect the natural process of oxidation and the mixing of blood with other fluids, certain colors may indicate underlying health conditions that warrant attention.

In this guide, we'll explore the spectrum of period blood colors, from bright red to black, and what each might signify about your health.

Bright Red
Fresh, bright red blood indicates a healthy, normal flow at the beginning of your period. This is fresh blood being expelled relatively quickly from the uterus. It's typically a sign that your flow is at its heaviest and the blood is moving rapidly enough that it doesn't have time to darken.

Cranberry Red
Cranberry-colored blood is typical during a regular flow. It's slightly darker than bright red as it's been in the uterus a bit longer. This is completely normal and indicates a healthy menstrual flow.

Dark Red
Dark red blood has been in the uterus longer and has had time to oxidize. This is common toward the end of your period or with a slower flow. It's generally not a cause for concern and is a normal part of your menstrual cycle.`,
  },
  {
    id: "ai-health-assistant",
    type: "article",
    title: "How AI is Revolutionizing Women's Health Tracking",
    description:
      "Discover how artificial intelligence is transforming the way women monitor and understand their health.",
    readTime: "5 min read",
    tags: ["AI", "Health Tech", "Women's Health", "Digital Health"],
    content: `Artificial intelligence (AI) is revolutionizing healthcare across all specialties, but its impact on women's health tracking is particularly significant. From predicting menstrual cycles with unprecedented accuracy to identifying patterns in symptoms that might indicate underlying health conditions, AI-powered tools are empowering women to take control of their health in ways that weren't possible just a few years ago.

Personalized Health Insights
Traditional period tracking apps simply record data and make basic predictions based on averages. AI-powered health assistants, however, learn from your personal data over time, recognizing patterns unique to your body. This allows them to provide increasingly accurate predictions and personalized insights about your cycle, fertility windows, and potential symptom patterns.

For example, by analyzing months of symptom data, AI can identify correlations between specific foods and digestive symptoms, or between stress levels and menstrual pain. These insights can help you make targeted lifestyle changes to improve your well-being.

Early Detection of Health Issues
One of the most promising applications of AI in women's health is the potential for early detection of conditions like endometriosis, PCOS, and perimenopause. These conditions are often diagnosed years after symptoms first appear, leading to unnecessary suffering and delayed treatment.`,
  },
  {
    id: "pcos-yoga-routine",
    type: "video",
    title: "Yoga for PCOS: 20-Minute Daily Routine",
    description: "A gentle yoga routine specifically designed to help manage PCOS symptoms and balance hormones.",
    duration: "20:15",
    videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
    tags: ["PCOS", "Yoga", "Exercise", "Hormonal Balance"],
    transcript: `Welcome to this specialized yoga routine for PCOS management. I'm Maya, a certified yoga instructor with a focus on women's health, and today I'll guide you through a 20-minute practice specifically designed to help balance hormones and reduce PCOS symptoms.

Polycystic Ovary Syndrome affects millions of women worldwide, and while yoga isn't a cure, research has shown that regular practice can help manage many symptoms by reducing stress hormones, improving insulin sensitivity, and promoting hormonal balance.

Before we begin, remember to listen to your body and modify any poses as needed. This practice is gentle but effective, focusing on poses that benefit the endocrine system and reproductive organs.

Let's start in a comfortable seated position. Close your eyes and take a few deep breaths, allowing your body to settle and your mind to become present. Today's practice will include twists to massage the internal organs, inversions to improve circulation to the endocrine glands, and gentle stretches to reduce stress.

Our first pose is Butterfly Pose, which helps open the pelvic area and stimulate the ovaries and reproductive organs...`,
  },
  {
    id: "pcos-anti-inflammatory-diet",
    type: "video",
    title: "Anti-Inflammatory Diet Plan for PCOS",
    description:
      "Learn how to create a PCOS-friendly meal plan focused on reducing inflammation and balancing hormones.",
    duration: "25:30",
    videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
    tags: ["PCOS", "Nutrition", "Anti-Inflammatory", "Diet"],
    transcript: `Hello and welcome to this comprehensive guide on anti-inflammatory eating for PCOS. I'm Dr. Nadia Chen, a nutritionist specializing in women's hormonal health, and today I'll walk you through creating an effective anti-inflammatory diet plan specifically for managing PCOS symptoms.

Inflammation plays a significant role in PCOS, often exacerbating symptoms like insulin resistance, hormonal imbalances, and even fertility challenges. The good news is that dietary choices can significantly impact inflammation levels in your body.

In this video, we'll cover:
1. The connection between inflammation and PCOS
2. Key anti-inflammatory foods to include daily
3. Foods to limit or avoid
4. A sample 7-day meal plan
5. Practical tips for implementation

Let's start by understanding why inflammation matters for PCOS. Research shows that women with PCOS often have higher levels of inflammatory markers in their blood. This chronic low-grade inflammation can worsen insulin resistance, which in turn drives many PCOS symptoms including irregular periods, excess androgen production, and metabolic issues.

By focusing on anti-inflammatory foods, we can help break this cycle and create an internal environment that supports hormonal balance...`,
  },
  {
    id: "pcos-strength-training",
    type: "video",
    title: "Strength Training Basics for Women with PCOS",
    description: "A beginner-friendly guide to strength training exercises that help manage PCOS symptoms.",
    duration: "18:45",
    videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
    tags: ["PCOS", "Strength Training", "Exercise", "Insulin Resistance"],
    transcript: `Welcome to this beginner-friendly guide  "Exercise", "Insulin Resistance"],
    transcript: \`Welcome to this beginner-friendly guide to strength training for women with PCOS. I'm Coach Emma, a certified personal trainer specializing in women's hormonal health, and today I'll be showing you how to get started with strength training to help manage your PCOS symptoms.

Strength training is particularly beneficial for women with PCOS for several reasons. Research shows that building muscle can improve insulin sensitivity, which is crucial since insulin resistance affects up to 70% of women with PCOS. Additionally, strength training can help with weight management, reduce inflammation, and boost your mood and energy levels.

In this video, we'll cover:
1. Why strength training works for PCOS
2. Essential equipment for beginners
3. Proper form for five foundational exercises
4. A simple twice-weekly routine to get started
5. Tips for progression and consistency

You don't need an expensive gym membership or complicated equipment to get started. I'll show you exercises you can do at home with just a few dumbbells or even using your body weight.

Remember, consistency is more important than intensity when you're beginning. Even 20-30 minutes twice a week can make a significant difference in how you feel and in managing your PCOS symptoms.

Let's start with proper breathing and form before moving into our first exercise: the squat...`,
  },
]
